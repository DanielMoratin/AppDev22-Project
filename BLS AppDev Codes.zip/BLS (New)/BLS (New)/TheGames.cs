﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS__New_
{
    public partial class TheGames : UserControl
    {
        public TheGames()
        {
            InitializeComponent();
        }

        private void TheGames_Load(object sender, EventArgs e)
        {

        }
    }
}
