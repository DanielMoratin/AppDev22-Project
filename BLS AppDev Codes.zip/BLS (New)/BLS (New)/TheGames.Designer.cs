﻿namespace BLS__New_
{
    partial class TheGames
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.team1name = new System.Windows.Forms.Label();
            this.team2name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.team1score = new System.Windows.Forms.Label();
            this.team2score = new System.Windows.Forms.Label();
            this.lblSched = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            this.SuspendLayout();
            // 
            // pb1
            // 
            this.pb1.BackColor = System.Drawing.Color.White;
            this.pb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb1.Location = new System.Drawing.Point(15, 12);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(70, 70);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1.TabIndex = 0;
            this.pb1.TabStop = false;
            // 
            // pb2
            // 
            this.pb2.BackColor = System.Drawing.Color.White;
            this.pb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb2.Location = new System.Drawing.Point(325, 12);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(70, 70);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2.TabIndex = 1;
            this.pb2.TabStop = false;
            // 
            // team1name
            // 
            this.team1name.AutoSize = true;
            this.team1name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.team1name.Location = new System.Drawing.Point(92, 22);
            this.team1name.Name = "team1name";
            this.team1name.Size = new System.Drawing.Size(52, 17);
            this.team1name.TabIndex = 2;
            this.team1name.Text = "label1";
            // 
            // team2name
            // 
            this.team2name.AutoSize = true;
            this.team2name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.team2name.Location = new System.Drawing.Point(401, 22);
            this.team2name.Name = "team2name";
            this.team2name.Size = new System.Drawing.Size(52, 17);
            this.team2name.TabIndex = 3;
            this.team2name.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(283, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "V.S.";
            // 
            // team1score
            // 
            this.team1score.AutoSize = true;
            this.team1score.Location = new System.Drawing.Point(92, 54);
            this.team1score.Name = "team1score";
            this.team1score.Size = new System.Drawing.Size(69, 13);
            this.team1score.TabIndex = 5;
            this.team1score.Text = "Final Score : ";
            // 
            // team2score
            // 
            this.team2score.AutoSize = true;
            this.team2score.Location = new System.Drawing.Point(401, 54);
            this.team2score.Name = "team2score";
            this.team2score.Size = new System.Drawing.Size(69, 13);
            this.team2score.TabIndex = 6;
            this.team2score.Text = "Final Score : ";
            // 
            // lblSched
            // 
            this.lblSched.AutoSize = true;
            this.lblSched.Location = new System.Drawing.Point(227, 88);
            this.lblSched.Name = "lblSched";
            this.lblSched.Size = new System.Drawing.Size(83, 13);
            this.lblSched.TabIndex = 7;
            this.lblSched.Text = "Game Schedule";
            // 
            // TheGames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.lblSched);
            this.Controls.Add(this.team2score);
            this.Controls.Add(this.team1score);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.team2name);
            this.Controls.Add(this.team1name);
            this.Controls.Add(this.pb2);
            this.Controls.Add(this.pb1);
            this.Name = "TheGames";
            this.Size = new System.Drawing.Size(598, 107);
            this.Load += new System.EventHandler(this.TheGames_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox pb1;
        public System.Windows.Forms.PictureBox pb2;
        public System.Windows.Forms.Label team1name;
        public System.Windows.Forms.Label team2name;
        public System.Windows.Forms.Label team1score;
        public System.Windows.Forms.Label team2score;
        public System.Windows.Forms.Label lblSched;
    }
}
