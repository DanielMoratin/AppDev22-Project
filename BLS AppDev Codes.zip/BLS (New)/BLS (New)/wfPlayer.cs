﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BLS__New_
{
    public partial class wfPlayer : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;

        Color c;
        public wfPlayer()
        {
            InitializeComponent();
        }

        private void wfPlayer_Load(object sender, EventArgs e)
        {
            btnAP_Click(sender, e);
            refresh1_Click( sender,  e);
            cbAPsort.SelectedIndex = 0;
            c = tbSearchAP.ForeColor;
            refreshCP_Click(sender, e);
            cbSortCP.SelectedIndex = 0;
            refreshFA_Click(sender, e);
        }

        private void btnAP_Click(object sender, EventArgs e)
        {
            pAP.Visible = true;
            pAP.BringToFront();
            pCP.Visible = false;
            pCP.SendToBack();
            pFA.Visible = false;
            pFA.SendToBack();
            lblTitle.Text = "BASKETBALL LEAGUE SYSTEM PLAYERS";
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "All Players List As Of " + strDT;

            pp1.Visible = true;
            pp2.Visible = true;
            pp3.Visible = false;
            pp4.Visible = false;
            pp5.Visible = false;
            pp6.Visible = false;
        }

        public void refresh1_Click(object sender, EventArgs e)
        {
            lvAP.Items.Clear();
            con.Open();
            if (cbAPsort.SelectedItem + "" == "Name") cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' Order by Lname");
            else cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' Order by Team");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString() + ", " + dr.GetValue(4).ToString() + " " + dr.GetValue(5).ToString();
                String itemTeam = dr.GetValue(8).ToString();
                String[] iRow = { itemI, itemName, itemPlace, itemTeam };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvAP.Items.Add(itemRow);
            }
            con.Close();
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "All Players List As Of" + strDT;
        }

        private void cbAPsort_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh1_Click(sender, e);
        }

        private void tbSearchAP_TextChanged(object sender, EventArgs e)
        {
            String tempS = tbSearchAP.Text;
            if (tempS == "Search Player") tempS = "";
            lvAP.Items.Clear();
            con.Open();
            if (cbAPsort.SelectedItem + "" == "Name") cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' and concat(Player_Id, Lname, Fname, Haddress, CityProv, Zip, Team)like '%'+@search+'%' Order by Lname");
            else cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' and concat(Player_Id, Lname, Fname, Haddress, CityProv, Zip, Team)like '%'+@search+'%' Order by Team");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tempS);
            dr = cmd.ExecuteReader();
            while(dr.Read()){
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString() + ", " + dr.GetValue(4).ToString() + " " + dr.GetValue(5).ToString();
                String itemTeam = dr.GetValue(8).ToString();
                String[] iRow = { itemI, itemName, itemPlace, itemTeam };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvAP.Items.Add(itemRow);
            }
            con.Close();
        }

        private void btnSearchAP_Click(object sender, EventArgs e)
        {
            tbSearchAP_TextChanged(sender, e);
        }

        private void tbSearchAP_Enter(object sender, EventArgs e)
        {
            if (tbSearchAP.Text == "Search Player")
            {
                tbSearchAP.Text = "";
                tbSearchAP.ForeColor = Color.Black;
            }
        }

        private void tbSearchAP_Leave(object sender, EventArgs e)
        {
            if (tbSearchAP.Text == "")
            {
                tbSearchAP.Text = "Search Player";
                tbSearchAP.ForeColor = c;
            }
            else
            {
                tbSearchAP.ForeColor = Color.Black;
            }
        }

        private void lvAP_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Form f = new Form();
            f.ShowDialog();
        }

        private void btnCP_Click(object sender, EventArgs e)
        {
            pCP.Visible = true;
            pCP.BringToFront();
            pAP.Visible = false;
            pAP.SendToBack();
            pFA.Visible = false;
            pFA.SendToBack();
            lblTitle.Text = "BASKETBALL LEAGUE SYSTEM CONTRACT PLAYERS";
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "All Contract Players List As Of " + strDT;

            pp1.Visible = false;
            pp2.Visible = false;
            pp3.Visible = true;
            pp4.Visible = true;
            pp5.Visible = false;
            pp6.Visible = false;
        }

        public void refreshCP_Click(object sender, EventArgs e)
        {
            lvCP.Items.Clear();
            con.Open();
            if (cbSortCP.SelectedItem + "" == "Name") cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' And Team != 'Free Agent' Order by Lname");
            else cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' And Team != 'Free Agent' Order by Team");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString() + ", " + dr.GetValue(4).ToString() + " " + dr.GetValue(5).ToString();
                String itemTeam = dr.GetValue(8).ToString();
                String[] iRow = { itemI, itemName, itemPlace, itemTeam };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvCP.Items.Add(itemRow);
            }
            con.Close();
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "All Contract Players List As Of" + strDT;
        }

        private void cbSortrCP_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshCP_Click(sender, e);
        }

        private void btnSearchCP_Click(object sender, EventArgs e)
        {
            tbSearchCP_TextChanged(sender, e);
        }

        private void tbSearchCP_TextChanged(object sender, EventArgs e)
        {
            String tempS = tbSearchCP.Text;
            if (tempS == "Search Player") tempS = "";
            lvCP.Items.Clear();
            con.Open();
            if (cbSortCP.SelectedItem + "" == "Name") cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' and Team != 'Free Agent' and concat(Player_Id, Lname, Fname, Haddress, CityProv, Zip, Team)like '%'+@search+'%' Order by Lname");
            else cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' and Team != 'Free Agent'  and concat(Player_Id, Lname, Fname, Haddress, CityProv, Zip, Team)like '%'+@search+'%' Order by Team");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tempS);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString() + ", " + dr.GetValue(4).ToString() + " " + dr.GetValue(5).ToString();
                String itemTeam = dr.GetValue(8).ToString();
                String[] iRow = { itemI, itemName, itemPlace, itemTeam };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvCP.Items.Add(itemRow);
            }
            con.Close();
        }

        private void tbSearchCP_Enter(object sender, EventArgs e)
        {
            if (tbSearchCP.Text == "Search Player")
            {
                tbSearchCP.Text = "";
                tbSearchCP.ForeColor = Color.Black;
            }
        }

        private void tbSearchCP_Leave(object sender, EventArgs e)
        {
            if (tbSearchCP.Text == "")
            {
                tbSearchCP.Text = "Search Player";
                tbSearchCP.ForeColor = c;
            }
            else
            {
                tbSearchCP.ForeColor = Color.Black;
            }
        }

        private void btnFA_Click(object sender, EventArgs e)
        {
            pFA.Visible = true;
            pFA.BringToFront();
            pAP.Visible = false;
            pAP.SendToBack();
            pCP.Visible = false;
            pCP.SendToBack();
            lblTitle.Text = "BASKETBALL LEAGUE SYSTEM FREE AGENTS";
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "All Free Agents List As Of " + strDT;

            pp1.Visible = false;
            pp2.Visible = false;
            pp3.Visible = false;
            pp4.Visible = false;
            pp5.Visible = true;
            pp6.Visible = true;
        }

        public void refreshFA_Click(object sender, EventArgs e)
        {
            lvFA.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' And Team = 'Free Agent' Order by Lname");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString() + ", " + dr.GetValue(4).ToString() + " " + dr.GetValue(5).ToString();
                String itemTeam = dr.GetValue(8).ToString();
                String[] iRow = { itemI, itemName, itemPlace, itemTeam };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvFA.Items.Add(itemRow);
            }
            con.Close();
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "All Free Agents List As Of " + strDT;
        }

        private void tbSearchFA_TextChanged(object sender, EventArgs e)
        {
            String tempS = tbSearchFA.Text;
            if (tempS == "Search Player") tempS = "";
            lvFA.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Player Where [Status] = 'Active' and Team = 'Free Agent' and concat(Player_Id, Lname, Fname, Haddress, CityProv, Zip, Team)like '%'+@search+'%' Order by Lname");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tempS);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString() + ", " + dr.GetValue(4).ToString() + " " + dr.GetValue(5).ToString();
                String itemTeam = dr.GetValue(8).ToString();
                String[] iRow = { itemI, itemName, itemPlace, itemTeam };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvFA.Items.Add(itemRow);
            }
            con.Close();
        }

        private void btnSearchFA_Click(object sender, EventArgs e)
        {
            tbSearchFA_TextChanged(sender, e);
        }

        private void tbSearchFA_Enter(object sender, EventArgs e)
        {
            if (tbSearchFA.Text == "Search Player")
            {
                tbSearchFA.Text = "";
                tbSearchFA.ForeColor = Color.Black;
            }
        }

        private void tbSearchFA_Leave(object sender, EventArgs e)
        {
            if (tbSearchFA.Text == "")
            {
                tbSearchFA.Text = "Search Player";
                tbSearchFA.ForeColor = c;
            }
            else
            {
                tbSearchFA.ForeColor = Color.Black;
            }
        }
    }
}
