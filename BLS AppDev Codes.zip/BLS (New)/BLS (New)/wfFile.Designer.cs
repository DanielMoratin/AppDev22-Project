﻿namespace BLS__New_
{
    partial class wfFile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wfFile));
            this.btnAEP = new System.Windows.Forms.Button();
            this.btnEAT = new System.Windows.Forms.Button();
            this.btnARR = new System.Windows.Forms.Button();
            this.pHeader = new System.Windows.Forms.Panel();
            this.lblDetial = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pPlayer = new System.Windows.Forms.Panel();
            this.lblNote = new System.Windows.Forms.Label();
            this.dgvPlayer = new System.Windows.Forms.DataGridView();
            this.btnSearchPlayer = new System.Windows.Forms.Button();
            this.tbSearchPlayer = new System.Windows.Forms.TextBox();
            this.gbPlayerInfo = new System.Windows.Forms.GroupBox();
            this.btnClearPlayer = new System.Windows.Forms.Button();
            this.btnAddPlayer = new System.Windows.Forms.Button();
            this.lblECPZ = new System.Windows.Forms.Label();
            this.lblEA = new System.Windows.Forms.Label();
            this.lblUpdatingP = new System.Windows.Forms.Label();
            this.lblEF = new System.Windows.Forms.Label();
            this.lblEL = new System.Windows.Forms.Label();
            this.btnChangePid = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cbSP = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbMP = new System.Windows.Forms.ComboBox();
            this.tbZC = new System.Windows.Forms.TextBox();
            this.tbCP = new System.Windows.Forms.TextBox();
            this.tbHomePlace = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbFname = new System.Windows.Forms.TextBox();
            this.tbLname = new System.Windows.Forms.TextBox();
            this.tbPlayerId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pTeam = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.dgvTeam = new System.Windows.Forms.DataGridView();
            this.btnSearchTeam = new System.Windows.Forms.Button();
            this.tbSearchTeam = new System.Windows.Forms.TextBox();
            this.gbTeamInfo = new System.Windows.Forms.GroupBox();
            this.lblCTP = new System.Windows.Forms.Label();
            this.pbTeamEdit = new System.Windows.Forms.PictureBox();
            this.btnClearTeam = new System.Windows.Forms.Button();
            this.btnAddTeam = new System.Windows.Forms.Button();
            this.eHT = new System.Windows.Forms.Label();
            this.lblUpdateTeam = new System.Windows.Forms.Label();
            this.eTO = new System.Windows.Forms.Label();
            this.eTN = new System.Windows.Forms.Label();
            this.btnChangeTid = new System.Windows.Forms.Button();
            this.tbTeamHome = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tbTeamOwner = new System.Windows.Forms.TextBox();
            this.tbTeamName = new System.Windows.Forms.TextBox();
            this.tbIdTeam = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pARroster = new System.Windows.Forms.Panel();
            this.tbSearchFreeAgent = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnRelease = new System.Windows.Forms.Button();
            this.btnAssign = new System.Windows.Forms.Button();
            this.cbTeamRoster = new System.Windows.Forms.ComboBox();
            this.lvAssignedPlayer = new System.Windows.Forms.ListView();
            this.AssignPlayerId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AssignPlayerName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvFreePlayer = new System.Windows.Forms.ListView();
            this.FreePlayerId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.FreePlayerName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refreshRoster = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pp4 = new System.Windows.Forms.Panel();
            this.pp3 = new System.Windows.Forms.Panel();
            this.pp2 = new System.Windows.Forms.Panel();
            this.pp1 = new System.Windows.Forms.Panel();
            this.pp6 = new System.Windows.Forms.Panel();
            this.pp5 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pHeader.SuspendLayout();
            this.pPlayer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlayer)).BeginInit();
            this.gbPlayerInfo.SuspendLayout();
            this.pTeam.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeam)).BeginInit();
            this.gbTeamInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTeamEdit)).BeginInit();
            this.pARroster.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAEP
            // 
            this.btnAEP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnAEP.FlatAppearance.BorderSize = 0;
            this.btnAEP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAEP.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAEP.ForeColor = System.Drawing.Color.White;
            this.btnAEP.Location = new System.Drawing.Point(54, 71);
            this.btnAEP.Name = "btnAEP";
            this.btnAEP.Size = new System.Drawing.Size(130, 24);
            this.btnAEP.TabIndex = 0;
            this.btnAEP.Text = "Add/Edit Player";
            this.btnAEP.UseVisualStyleBackColor = false;
            this.btnAEP.Click += new System.EventHandler(this.btnAEP_Click);
            // 
            // btnEAT
            // 
            this.btnEAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnEAT.FlatAppearance.BorderSize = 0;
            this.btnEAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEAT.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEAT.ForeColor = System.Drawing.Color.White;
            this.btnEAT.Location = new System.Drawing.Point(258, 71);
            this.btnEAT.Name = "btnEAT";
            this.btnEAT.Size = new System.Drawing.Size(130, 24);
            this.btnEAT.TabIndex = 1;
            this.btnEAT.Text = "Add/Edit Team";
            this.btnEAT.UseVisualStyleBackColor = false;
            this.btnEAT.Click += new System.EventHandler(this.btnEAT_Click);
            // 
            // btnARR
            // 
            this.btnARR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnARR.FlatAppearance.BorderSize = 0;
            this.btnARR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnARR.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnARR.ForeColor = System.Drawing.Color.White;
            this.btnARR.Location = new System.Drawing.Point(473, 71);
            this.btnARR.Name = "btnARR";
            this.btnARR.Size = new System.Drawing.Size(130, 24);
            this.btnARR.TabIndex = 2;
            this.btnARR.Text = "Assign/Release Roster";
            this.btnARR.UseVisualStyleBackColor = false;
            this.btnARR.Click += new System.EventHandler(this.btnARR_Click);
            // 
            // pHeader
            // 
            this.pHeader.Controls.Add(this.pictureBox2);
            this.pHeader.Controls.Add(this.pp6);
            this.pHeader.Controls.Add(this.pp5);
            this.pHeader.Controls.Add(this.pp2);
            this.pHeader.Controls.Add(this.pp1);
            this.pHeader.Controls.Add(this.pp4);
            this.pHeader.Controls.Add(this.pp3);
            this.pHeader.Controls.Add(this.panel2);
            this.pHeader.Controls.Add(this.panel1);
            this.pHeader.Controls.Add(this.lblDetial);
            this.pHeader.Controls.Add(this.lblTitle);
            this.pHeader.Controls.Add(this.btnAEP);
            this.pHeader.Controls.Add(this.btnARR);
            this.pHeader.Controls.Add(this.btnEAT);
            this.pHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pHeader.Location = new System.Drawing.Point(0, 0);
            this.pHeader.Name = "pHeader";
            this.pHeader.Size = new System.Drawing.Size(686, 100);
            this.pHeader.TabIndex = 3;
            // 
            // lblDetial
            // 
            this.lblDetial.AutoSize = true;
            this.lblDetial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetial.Location = new System.Drawing.Point(37, 42);
            this.lblDetial.Name = "lblDetial";
            this.lblDetial.Size = new System.Drawing.Size(294, 15);
            this.lblDetial.TabIndex = 4;
            this.lblDetial.Text = "ADD new or UPDATE existing PLAYER to the system.";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(34, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(170, 34);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "Add/Edit Player";
            // 
            // pPlayer
            // 
            this.pPlayer.AutoScroll = true;
            this.pPlayer.Controls.Add(this.lblNote);
            this.pPlayer.Controls.Add(this.dgvPlayer);
            this.pPlayer.Controls.Add(this.btnSearchPlayer);
            this.pPlayer.Controls.Add(this.tbSearchPlayer);
            this.pPlayer.Controls.Add(this.gbPlayerInfo);
            this.pPlayer.Location = new System.Drawing.Point(4, 107);
            this.pPlayer.Name = "pPlayer";
            this.pPlayer.Size = new System.Drawing.Size(679, 340);
            this.pPlayer.TabIndex = 4;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(388, 321);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(245, 13);
            this.lblNote.TabIndex = 5;
            this.lblNote.Text = "Note : Double click the row of the player to update";
            // 
            // dgvPlayer
            // 
            this.dgvPlayer.AllowUserToAddRows = false;
            this.dgvPlayer.AllowUserToDeleteRows = false;
            this.dgvPlayer.AllowUserToResizeRows = false;
            this.dgvPlayer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPlayer.EnableHeadersVisualStyles = false;
            this.dgvPlayer.Location = new System.Drawing.Point(339, 40);
            this.dgvPlayer.MultiSelect = false;
            this.dgvPlayer.Name = "dgvPlayer";
            this.dgvPlayer.ReadOnly = true;
            this.dgvPlayer.RowHeadersVisible = false;
            this.dgvPlayer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPlayer.Size = new System.Drawing.Size(330, 278);
            this.dgvPlayer.TabIndex = 3;
            this.dgvPlayer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPlayer_CellDoubleClick);
            // 
            // btnSearchPlayer
            // 
            this.btnSearchPlayer.Location = new System.Drawing.Point(550, 11);
            this.btnSearchPlayer.Name = "btnSearchPlayer";
            this.btnSearchPlayer.Size = new System.Drawing.Size(84, 23);
            this.btnSearchPlayer.TabIndex = 2;
            this.btnSearchPlayer.Text = "Search Player";
            this.btnSearchPlayer.UseVisualStyleBackColor = true;
            // 
            // tbSearchPlayer
            // 
            this.tbSearchPlayer.Location = new System.Drawing.Point(414, 13);
            this.tbSearchPlayer.Name = "tbSearchPlayer";
            this.tbSearchPlayer.Size = new System.Drawing.Size(130, 20);
            this.tbSearchPlayer.TabIndex = 1;
            this.tbSearchPlayer.TextChanged += new System.EventHandler(this.tbSearchPlayer_TextChanged);
            // 
            // gbPlayerInfo
            // 
            this.gbPlayerInfo.Controls.Add(this.btnClearPlayer);
            this.gbPlayerInfo.Controls.Add(this.btnAddPlayer);
            this.gbPlayerInfo.Controls.Add(this.lblECPZ);
            this.gbPlayerInfo.Controls.Add(this.lblEA);
            this.gbPlayerInfo.Controls.Add(this.lblUpdatingP);
            this.gbPlayerInfo.Controls.Add(this.lblEF);
            this.gbPlayerInfo.Controls.Add(this.lblEL);
            this.gbPlayerInfo.Controls.Add(this.btnChangePid);
            this.gbPlayerInfo.Controls.Add(this.label8);
            this.gbPlayerInfo.Controls.Add(this.cbSP);
            this.gbPlayerInfo.Controls.Add(this.label7);
            this.gbPlayerInfo.Controls.Add(this.cbMP);
            this.gbPlayerInfo.Controls.Add(this.tbZC);
            this.gbPlayerInfo.Controls.Add(this.tbCP);
            this.gbPlayerInfo.Controls.Add(this.tbHomePlace);
            this.gbPlayerInfo.Controls.Add(this.label6);
            this.gbPlayerInfo.Controls.Add(this.label5);
            this.gbPlayerInfo.Controls.Add(this.label4);
            this.gbPlayerInfo.Controls.Add(this.tbFname);
            this.gbPlayerInfo.Controls.Add(this.tbLname);
            this.gbPlayerInfo.Controls.Add(this.tbPlayerId);
            this.gbPlayerInfo.Controls.Add(this.label3);
            this.gbPlayerInfo.Controls.Add(this.label2);
            this.gbPlayerInfo.Controls.Add(this.label1);
            this.gbPlayerInfo.Location = new System.Drawing.Point(0, 0);
            this.gbPlayerInfo.Name = "gbPlayerInfo";
            this.gbPlayerInfo.Size = new System.Drawing.Size(330, 340);
            this.gbPlayerInfo.TabIndex = 0;
            this.gbPlayerInfo.TabStop = false;
            this.gbPlayerInfo.Text = "Player Information";
            // 
            // btnClearPlayer
            // 
            this.btnClearPlayer.Location = new System.Drawing.Point(171, 300);
            this.btnClearPlayer.Name = "btnClearPlayer";
            this.btnClearPlayer.Size = new System.Drawing.Size(75, 23);
            this.btnClearPlayer.TabIndex = 23;
            this.btnClearPlayer.Text = "Clear";
            this.btnClearPlayer.UseVisualStyleBackColor = true;
            this.btnClearPlayer.Click += new System.EventHandler(this.btnClearPlayer_Click);
            // 
            // btnAddPlayer
            // 
            this.btnAddPlayer.Location = new System.Drawing.Point(82, 300);
            this.btnAddPlayer.Name = "btnAddPlayer";
            this.btnAddPlayer.Size = new System.Drawing.Size(75, 23);
            this.btnAddPlayer.TabIndex = 21;
            this.btnAddPlayer.Text = "Add";
            this.btnAddPlayer.UseVisualStyleBackColor = true;
            this.btnAddPlayer.Click += new System.EventHandler(this.btnAddPlayer_Click);
            // 
            // lblECPZ
            // 
            this.lblECPZ.AutoSize = true;
            this.lblECPZ.ForeColor = System.Drawing.Color.Red;
            this.lblECPZ.Location = new System.Drawing.Point(33, 234);
            this.lblECPZ.Name = "lblECPZ";
            this.lblECPZ.Size = new System.Drawing.Size(269, 13);
            this.lblECPZ.TabIndex = 20;
            this.lblECPZ.Text = "*Error: need CITY/PROVINCE and ZIP CODE inputted*";
            this.lblECPZ.Visible = false;
            // 
            // lblEA
            // 
            this.lblEA.AutoSize = true;
            this.lblEA.ForeColor = System.Drawing.Color.Red;
            this.lblEA.Location = new System.Drawing.Point(33, 181);
            this.lblEA.Name = "lblEA";
            this.lblEA.Size = new System.Drawing.Size(163, 13);
            this.lblEA.TabIndex = 19;
            this.lblEA.Text = "*Error: need ADDRESS inputted*";
            this.lblEA.Visible = false;
            // 
            // lblUpdatingP
            // 
            this.lblUpdatingP.AutoSize = true;
            this.lblUpdatingP.ForeColor = System.Drawing.Color.Blue;
            this.lblUpdatingP.Location = new System.Drawing.Point(233, 11);
            this.lblUpdatingP.Name = "lblUpdatingP";
            this.lblUpdatingP.Size = new System.Drawing.Size(91, 13);
            this.lblUpdatingP.TabIndex = 18;
            this.lblUpdatingP.Text = "Updating Player...";
            this.lblUpdatingP.Visible = false;
            // 
            // lblEF
            // 
            this.lblEF.AutoSize = true;
            this.lblEF.ForeColor = System.Drawing.Color.Red;
            this.lblEF.Location = new System.Drawing.Point(104, 127);
            this.lblEF.Name = "lblEF";
            this.lblEF.Size = new System.Drawing.Size(176, 13);
            this.lblEF.TabIndex = 17;
            this.lblEF.Text = "*Error: need FIRST NAME inputted*";
            this.lblEF.Visible = false;
            // 
            // lblEL
            // 
            this.lblEL.AutoSize = true;
            this.lblEL.ForeColor = System.Drawing.Color.Red;
            this.lblEL.Location = new System.Drawing.Point(104, 90);
            this.lblEL.Name = "lblEL";
            this.lblEL.Size = new System.Drawing.Size(172, 13);
            this.lblEL.TabIndex = 6;
            this.lblEL.Text = "*Error: need LAST NAME inputted*";
            this.lblEL.Visible = false;
            // 
            // btnChangePid
            // 
            this.btnChangePid.Location = new System.Drawing.Point(213, 30);
            this.btnChangePid.Name = "btnChangePid";
            this.btnChangePid.Size = new System.Drawing.Size(75, 23);
            this.btnChangePid.TabIndex = 16;
            this.btnChangePid.Text = "Change";
            this.btnChangePid.UseVisualStyleBackColor = true;
            this.btnChangePid.Click += new System.EventHandler(this.btnChangPid_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(169, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Secondary Position : ";
            // 
            // cbSP
            // 
            this.cbSP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSP.FormattingEnabled = true;
            this.cbSP.Items.AddRange(new object[] {
            "Center",
            "Point Guard",
            "Power Forward",
            "Shooting Guard",
            "Small Forward"});
            this.cbSP.Location = new System.Drawing.Point(171, 266);
            this.cbSP.Name = "cbSP";
            this.cbSP.Size = new System.Drawing.Size(121, 21);
            this.cbSP.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Main Position : ";
            // 
            // cbMP
            // 
            this.cbMP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMP.FormattingEnabled = true;
            this.cbMP.Items.AddRange(new object[] {
            "Center",
            "Point Guard",
            "Power Forward",
            "Shooting Guard",
            "Small Forward"});
            this.cbMP.Location = new System.Drawing.Point(36, 266);
            this.cbMP.Name = "cbMP";
            this.cbMP.Size = new System.Drawing.Size(121, 21);
            this.cbMP.TabIndex = 12;
            // 
            // tbZC
            // 
            this.tbZC.Location = new System.Drawing.Point(220, 213);
            this.tbZC.MaxLength = 9;
            this.tbZC.Name = "tbZC";
            this.tbZC.Size = new System.Drawing.Size(60, 20);
            this.tbZC.TabIndex = 11;
            // 
            // tbCP
            // 
            this.tbCP.Location = new System.Drawing.Point(36, 213);
            this.tbCP.MaxLength = 50;
            this.tbCP.Name = "tbCP";
            this.tbCP.Size = new System.Drawing.Size(159, 20);
            this.tbCP.TabIndex = 10;
            // 
            // tbHomePlace
            // 
            this.tbHomePlace.Location = new System.Drawing.Point(36, 160);
            this.tbHomePlace.MaxLength = 100;
            this.tbHomePlace.Name = "tbHomePlace";
            this.tbHomePlace.Size = new System.Drawing.Size(256, 20);
            this.tbHomePlace.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(217, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Zip Code : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "City/Province : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Home Place : ";
            // 
            // tbFname
            // 
            this.tbFname.Location = new System.Drawing.Point(107, 106);
            this.tbFname.MaxLength = 50;
            this.tbFname.Name = "tbFname";
            this.tbFname.Size = new System.Drawing.Size(185, 20);
            this.tbFname.TabIndex = 5;
            // 
            // tbLname
            // 
            this.tbLname.Location = new System.Drawing.Point(107, 69);
            this.tbLname.MaxLength = 50;
            this.tbLname.Name = "tbLname";
            this.tbLname.Size = new System.Drawing.Size(185, 20);
            this.tbLname.TabIndex = 4;
            // 
            // tbPlayerId
            // 
            this.tbPlayerId.Enabled = false;
            this.tbPlayerId.Location = new System.Drawing.Point(107, 32);
            this.tbPlayerId.Name = "tbPlayerId";
            this.tbPlayerId.Size = new System.Drawing.Size(100, 20);
            this.tbPlayerId.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "First Name : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "I.D. : ";
            // 
            // pTeam
            // 
            this.pTeam.AutoScroll = true;
            this.pTeam.Controls.Add(this.label9);
            this.pTeam.Controls.Add(this.dgvTeam);
            this.pTeam.Controls.Add(this.btnSearchTeam);
            this.pTeam.Controls.Add(this.tbSearchTeam);
            this.pTeam.Controls.Add(this.gbTeamInfo);
            this.pTeam.Location = new System.Drawing.Point(4, 107);
            this.pTeam.Name = "pTeam";
            this.pTeam.Size = new System.Drawing.Size(679, 340);
            this.pTeam.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(388, 321);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(245, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Note : Double click the row of the player to update";
            // 
            // dgvTeam
            // 
            this.dgvTeam.AllowUserToAddRows = false;
            this.dgvTeam.AllowUserToDeleteRows = false;
            this.dgvTeam.AllowUserToResizeRows = false;
            this.dgvTeam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTeam.EnableHeadersVisualStyles = false;
            this.dgvTeam.Location = new System.Drawing.Point(339, 40);
            this.dgvTeam.MultiSelect = false;
            this.dgvTeam.Name = "dgvTeam";
            this.dgvTeam.ReadOnly = true;
            this.dgvTeam.RowHeadersVisible = false;
            this.dgvTeam.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTeam.Size = new System.Drawing.Size(330, 278);
            this.dgvTeam.TabIndex = 3;
            this.dgvTeam.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTeam_CellDoubleClick);
            // 
            // btnSearchTeam
            // 
            this.btnSearchTeam.Location = new System.Drawing.Point(550, 11);
            this.btnSearchTeam.Name = "btnSearchTeam";
            this.btnSearchTeam.Size = new System.Drawing.Size(84, 23);
            this.btnSearchTeam.TabIndex = 2;
            this.btnSearchTeam.Text = "Search Team";
            this.btnSearchTeam.UseVisualStyleBackColor = true;
            // 
            // tbSearchTeam
            // 
            this.tbSearchTeam.Location = new System.Drawing.Point(414, 13);
            this.tbSearchTeam.Name = "tbSearchTeam";
            this.tbSearchTeam.Size = new System.Drawing.Size(130, 20);
            this.tbSearchTeam.TabIndex = 1;
            this.tbSearchTeam.TextChanged += new System.EventHandler(this.tbSearchTeam_TextChanged);
            // 
            // gbTeamInfo
            // 
            this.gbTeamInfo.Controls.Add(this.lblCTP);
            this.gbTeamInfo.Controls.Add(this.pbTeamEdit);
            this.gbTeamInfo.Controls.Add(this.btnClearTeam);
            this.gbTeamInfo.Controls.Add(this.btnAddTeam);
            this.gbTeamInfo.Controls.Add(this.eHT);
            this.gbTeamInfo.Controls.Add(this.lblUpdateTeam);
            this.gbTeamInfo.Controls.Add(this.eTO);
            this.gbTeamInfo.Controls.Add(this.eTN);
            this.gbTeamInfo.Controls.Add(this.btnChangeTid);
            this.gbTeamInfo.Controls.Add(this.tbTeamHome);
            this.gbTeamInfo.Controls.Add(this.label19);
            this.gbTeamInfo.Controls.Add(this.tbTeamOwner);
            this.gbTeamInfo.Controls.Add(this.tbTeamName);
            this.gbTeamInfo.Controls.Add(this.tbIdTeam);
            this.gbTeamInfo.Controls.Add(this.label20);
            this.gbTeamInfo.Controls.Add(this.label21);
            this.gbTeamInfo.Controls.Add(this.label22);
            this.gbTeamInfo.Location = new System.Drawing.Point(0, 0);
            this.gbTeamInfo.Name = "gbTeamInfo";
            this.gbTeamInfo.Size = new System.Drawing.Size(330, 340);
            this.gbTeamInfo.TabIndex = 0;
            this.gbTeamInfo.TabStop = false;
            this.gbTeamInfo.Text = "Team Information";
            // 
            // lblCTP
            // 
            this.lblCTP.AutoSize = true;
            this.lblCTP.ForeColor = System.Drawing.Color.Blue;
            this.lblCTP.Location = new System.Drawing.Point(202, 60);
            this.lblCTP.Name = "lblCTP";
            this.lblCTP.Size = new System.Drawing.Size(100, 13);
            this.lblCTP.TabIndex = 25;
            this.lblCTP.Text = "Change team photo";
            this.lblCTP.Visible = false;
            // 
            // pbTeamEdit
            // 
            this.pbTeamEdit.BackColor = System.Drawing.Color.White;
            this.pbTeamEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTeamEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbTeamEdit.Image = ((System.Drawing.Image)(resources.GetObject("pbTeamEdit.Image")));
            this.pbTeamEdit.Location = new System.Drawing.Point(99, 16);
            this.pbTeamEdit.Margin = new System.Windows.Forms.Padding(0);
            this.pbTeamEdit.Name = "pbTeamEdit";
            this.pbTeamEdit.Size = new System.Drawing.Size(100, 100);
            this.pbTeamEdit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbTeamEdit.TabIndex = 24;
            this.pbTeamEdit.TabStop = false;
            this.pbTeamEdit.Click += new System.EventHandler(this.pbTeamEdit_Click);
            this.pbTeamEdit.MouseLeave += new System.EventHandler(this.pbTeamEdit_MouseLeave);
            this.pbTeamEdit.MouseHover += new System.EventHandler(this.pbTeamEdit_MouseHover);
            // 
            // btnClearTeam
            // 
            this.btnClearTeam.Location = new System.Drawing.Point(171, 300);
            this.btnClearTeam.Name = "btnClearTeam";
            this.btnClearTeam.Size = new System.Drawing.Size(75, 23);
            this.btnClearTeam.TabIndex = 23;
            this.btnClearTeam.Text = "Clear";
            this.btnClearTeam.UseVisualStyleBackColor = true;
            this.btnClearTeam.Click += new System.EventHandler(this.btnClearTeam_Click);
            // 
            // btnAddTeam
            // 
            this.btnAddTeam.Location = new System.Drawing.Point(82, 300);
            this.btnAddTeam.Name = "btnAddTeam";
            this.btnAddTeam.Size = new System.Drawing.Size(75, 23);
            this.btnAddTeam.TabIndex = 21;
            this.btnAddTeam.Text = "Add";
            this.btnAddTeam.UseVisualStyleBackColor = true;
            this.btnAddTeam.Click += new System.EventHandler(this.btnAddTeam_Click);
            // 
            // eHT
            // 
            this.eHT.AutoSize = true;
            this.eHT.ForeColor = System.Drawing.Color.Red;
            this.eHT.Location = new System.Drawing.Point(33, 268);
            this.eHT.Name = "eHT";
            this.eHT.Size = new System.Drawing.Size(180, 13);
            this.eHT.TabIndex = 19;
            this.eHT.Text = "*Error: need HOME TOWN inputted*";
            this.eHT.Visible = false;
            // 
            // lblUpdateTeam
            // 
            this.lblUpdateTeam.AutoSize = true;
            this.lblUpdateTeam.ForeColor = System.Drawing.Color.Blue;
            this.lblUpdateTeam.Location = new System.Drawing.Point(233, 11);
            this.lblUpdateTeam.Name = "lblUpdateTeam";
            this.lblUpdateTeam.Size = new System.Drawing.Size(89, 13);
            this.lblUpdateTeam.TabIndex = 18;
            this.lblUpdateTeam.Text = "Updating Team...";
            this.lblUpdateTeam.Visible = false;
            // 
            // eTO
            // 
            this.eTO.AutoSize = true;
            this.eTO.ForeColor = System.Drawing.Color.Red;
            this.eTO.Location = new System.Drawing.Point(104, 214);
            this.eTO.Name = "eTO";
            this.eTO.Size = new System.Drawing.Size(186, 13);
            this.eTO.TabIndex = 17;
            this.eTO.Text = "*Error: need TEAM OWNER inputted*";
            this.eTO.Visible = false;
            // 
            // eTN
            // 
            this.eTN.AutoSize = true;
            this.eTN.ForeColor = System.Drawing.Color.Red;
            this.eTN.Location = new System.Drawing.Point(104, 177);
            this.eTN.Name = "eTN";
            this.eTN.Size = new System.Drawing.Size(175, 13);
            this.eTN.TabIndex = 6;
            this.eTN.Text = "*Error: need TEAM NAME inputted*";
            this.eTN.Visible = false;
            // 
            // btnChangeTid
            // 
            this.btnChangeTid.Location = new System.Drawing.Point(213, 117);
            this.btnChangeTid.Name = "btnChangeTid";
            this.btnChangeTid.Size = new System.Drawing.Size(75, 23);
            this.btnChangeTid.TabIndex = 16;
            this.btnChangeTid.Text = "Change";
            this.btnChangeTid.UseVisualStyleBackColor = true;
            this.btnChangeTid.Click += new System.EventHandler(this.btnChangeTid_Click);
            // 
            // tbTeamHome
            // 
            this.tbTeamHome.Location = new System.Drawing.Point(36, 247);
            this.tbTeamHome.MaxLength = 100;
            this.tbTeamHome.Name = "tbTeamHome";
            this.tbTeamHome.Size = new System.Drawing.Size(256, 20);
            this.tbTeamHome.TabIndex = 9;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(33, 231);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 13);
            this.label19.TabIndex = 6;
            this.label19.Text = "Home Town : ";
            // 
            // tbTeamOwner
            // 
            this.tbTeamOwner.Location = new System.Drawing.Point(107, 193);
            this.tbTeamOwner.MaxLength = 50;
            this.tbTeamOwner.Name = "tbTeamOwner";
            this.tbTeamOwner.Size = new System.Drawing.Size(185, 20);
            this.tbTeamOwner.TabIndex = 5;
            // 
            // tbTeamName
            // 
            this.tbTeamName.Location = new System.Drawing.Point(107, 156);
            this.tbTeamName.MaxLength = 50;
            this.tbTeamName.Name = "tbTeamName";
            this.tbTeamName.Size = new System.Drawing.Size(185, 20);
            this.tbTeamName.TabIndex = 4;
            // 
            // tbIdTeam
            // 
            this.tbIdTeam.Enabled = false;
            this.tbIdTeam.Location = new System.Drawing.Point(107, 119);
            this.tbIdTeam.Name = "tbIdTeam";
            this.tbIdTeam.Size = new System.Drawing.Size(100, 20);
            this.tbIdTeam.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(33, 196);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Team Owner : ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(33, 159);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(74, 13);
            this.label21.TabIndex = 1;
            this.label21.Text = "Team Name : ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(33, 122);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(63, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Team I.D. : ";
            // 
            // pARroster
            // 
            this.pARroster.AutoScroll = true;
            this.pARroster.Controls.Add(this.tbSearchFreeAgent);
            this.pARroster.Controls.Add(this.label11);
            this.pARroster.Controls.Add(this.label10);
            this.pARroster.Controls.Add(this.btnRelease);
            this.pARroster.Controls.Add(this.btnAssign);
            this.pARroster.Controls.Add(this.cbTeamRoster);
            this.pARroster.Controls.Add(this.lvAssignedPlayer);
            this.pARroster.Controls.Add(this.lvFreePlayer);
            this.pARroster.Controls.Add(this.refreshRoster);
            this.pARroster.Location = new System.Drawing.Point(4, 107);
            this.pARroster.Name = "pARroster";
            this.pARroster.Size = new System.Drawing.Size(679, 340);
            this.pARroster.TabIndex = 7;
            // 
            // tbSearchFreeAgent
            // 
            this.tbSearchFreeAgent.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSearchFreeAgent.Location = new System.Drawing.Point(455, 18);
            this.tbSearchFreeAgent.Name = "tbSearchFreeAgent";
            this.tbSearchFreeAgent.Size = new System.Drawing.Size(114, 20);
            this.tbSearchFreeAgent.TabIndex = 8;
            this.tbSearchFreeAgent.Text = "Search Player";
            this.tbSearchFreeAgent.TextChanged += new System.EventHandler(this.tbSearchFreeAgent_TextChanged);
            this.tbSearchFreeAgent.Enter += new System.EventHandler(this.tbSearchFreeAgent_Enter);
            this.tbSearchFreeAgent.Leave += new System.EventHandler(this.tbSearchFreeAgent_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(381, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Free Agent : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Team Roster : ";
            // 
            // btnRelease
            // 
            this.btnRelease.Location = new System.Drawing.Point(300, 144);
            this.btnRelease.Name = "btnRelease";
            this.btnRelease.Size = new System.Drawing.Size(75, 23);
            this.btnRelease.TabIndex = 5;
            this.btnRelease.Text = "Release";
            this.btnRelease.UseVisualStyleBackColor = true;
            this.btnRelease.Click += new System.EventHandler(this.btnRelease_Click);
            // 
            // btnAssign
            // 
            this.btnAssign.Location = new System.Drawing.Point(300, 90);
            this.btnAssign.Name = "btnAssign";
            this.btnAssign.Size = new System.Drawing.Size(75, 23);
            this.btnAssign.TabIndex = 4;
            this.btnAssign.Text = "Assign";
            this.btnAssign.UseVisualStyleBackColor = true;
            this.btnAssign.Click += new System.EventHandler(this.btnAssign_Click);
            // 
            // cbTeamRoster
            // 
            this.cbTeamRoster.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTeamRoster.FormattingEnabled = true;
            this.cbTeamRoster.Location = new System.Drawing.Point(89, 18);
            this.cbTeamRoster.Name = "cbTeamRoster";
            this.cbTeamRoster.Size = new System.Drawing.Size(188, 21);
            this.cbTeamRoster.Sorted = true;
            this.cbTeamRoster.TabIndex = 3;
            this.cbTeamRoster.SelectedIndexChanged += new System.EventHandler(this.cbTeamRoster_SelectedIndexChanged);
            // 
            // lvAssignedPlayer
            // 
            this.lvAssignedPlayer.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.AssignPlayerId,
            this.AssignPlayerName});
            this.lvAssignedPlayer.FullRowSelect = true;
            this.lvAssignedPlayer.GridLines = true;
            this.lvAssignedPlayer.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvAssignedPlayer.HideSelection = false;
            this.lvAssignedPlayer.Location = new System.Drawing.Point(6, 44);
            this.lvAssignedPlayer.MultiSelect = false;
            this.lvAssignedPlayer.Name = "lvAssignedPlayer";
            this.lvAssignedPlayer.Size = new System.Drawing.Size(285, 290);
            this.lvAssignedPlayer.TabIndex = 2;
            this.lvAssignedPlayer.UseCompatibleStateImageBehavior = false;
            this.lvAssignedPlayer.View = System.Windows.Forms.View.Details;
            // 
            // AssignPlayerId
            // 
            this.AssignPlayerId.Text = "ID";
            this.AssignPlayerId.Width = 114;
            // 
            // AssignPlayerName
            // 
            this.AssignPlayerName.Text = "Name";
            this.AssignPlayerName.Width = 167;
            // 
            // lvFreePlayer
            // 
            this.lvFreePlayer.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.FreePlayerId,
            this.FreePlayerName});
            this.lvFreePlayer.FullRowSelect = true;
            this.lvFreePlayer.GridLines = true;
            this.lvFreePlayer.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvFreePlayer.HideSelection = false;
            this.lvFreePlayer.Location = new System.Drawing.Point(384, 44);
            this.lvFreePlayer.MultiSelect = false;
            this.lvFreePlayer.Name = "lvFreePlayer";
            this.lvFreePlayer.Size = new System.Drawing.Size(285, 290);
            this.lvFreePlayer.TabIndex = 1;
            this.lvFreePlayer.TileSize = new System.Drawing.Size(1, 1);
            this.lvFreePlayer.UseCompatibleStateImageBehavior = false;
            this.lvFreePlayer.View = System.Windows.Forms.View.Details;
            // 
            // FreePlayerId
            // 
            this.FreePlayerId.Text = "ID";
            this.FreePlayerId.Width = 114;
            // 
            // FreePlayerName
            // 
            this.FreePlayerName.Text = "Name";
            this.FreePlayerName.Width = 167;
            // 
            // refreshRoster
            // 
            this.refreshRoster.AutoSize = true;
            this.refreshRoster.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshRoster.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshRoster.ForeColor = System.Drawing.Color.Blue;
            this.refreshRoster.Location = new System.Drawing.Point(625, 11);
            this.refreshRoster.Name = "refreshRoster";
            this.refreshRoster.Size = new System.Drawing.Size(44, 13);
            this.refreshRoster.TabIndex = 0;
            this.refreshRoster.Text = "Refresh";
            this.refreshRoster.Click += new System.EventHandler(this.refreshRoster_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(0, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(686, 3);
            this.panel2.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(686, 1);
            this.panel1.TabIndex = 14;
            // 
            // pp4
            // 
            this.pp4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp4.Location = new System.Drawing.Point(378, 71);
            this.pp4.Name = "pp4";
            this.pp4.Size = new System.Drawing.Size(10, 24);
            this.pp4.TabIndex = 25;
            this.pp4.Visible = false;
            // 
            // pp3
            // 
            this.pp3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp3.Location = new System.Drawing.Point(257, 71);
            this.pp3.Name = "pp3";
            this.pp3.Size = new System.Drawing.Size(10, 24);
            this.pp3.TabIndex = 24;
            this.pp3.Visible = false;
            // 
            // pp2
            // 
            this.pp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp2.Location = new System.Drawing.Point(175, 71);
            this.pp2.Name = "pp2";
            this.pp2.Size = new System.Drawing.Size(10, 24);
            this.pp2.TabIndex = 27;
            this.pp2.Visible = false;
            // 
            // pp1
            // 
            this.pp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp1.Location = new System.Drawing.Point(54, 71);
            this.pp1.Name = "pp1";
            this.pp1.Size = new System.Drawing.Size(10, 24);
            this.pp1.TabIndex = 26;
            this.pp1.Visible = false;
            // 
            // pp6
            // 
            this.pp6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp6.Location = new System.Drawing.Point(594, 71);
            this.pp6.Name = "pp6";
            this.pp6.Size = new System.Drawing.Size(10, 24);
            this.pp6.TabIndex = 29;
            this.pp6.Visible = false;
            // 
            // pp5
            // 
            this.pp5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp5.Location = new System.Drawing.Point(473, 71);
            this.pp5.Name = "pp5";
            this.pp5.Size = new System.Drawing.Size(10, 24);
            this.pp5.TabIndex = 28;
            this.pp5.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(600, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(83, 68);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            // 
            // wfFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.pARroster);
            this.Controls.Add(this.pTeam);
            this.Controls.Add(this.pPlayer);
            this.Controls.Add(this.pHeader);
            this.Name = "wfFile";
            this.Size = new System.Drawing.Size(686, 450);
            this.Load += new System.EventHandler(this.wfFile_Load);
            this.pHeader.ResumeLayout(false);
            this.pHeader.PerformLayout();
            this.pPlayer.ResumeLayout(false);
            this.pPlayer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlayer)).EndInit();
            this.gbPlayerInfo.ResumeLayout(false);
            this.gbPlayerInfo.PerformLayout();
            this.pTeam.ResumeLayout(false);
            this.pTeam.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeam)).EndInit();
            this.gbTeamInfo.ResumeLayout(false);
            this.gbTeamInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTeamEdit)).EndInit();
            this.pARroster.ResumeLayout(false);
            this.pARroster.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAEP;
        private System.Windows.Forms.Button btnEAT;
        private System.Windows.Forms.Button btnARR;
        private System.Windows.Forms.Panel pHeader;
        private System.Windows.Forms.Label lblDetial;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pPlayer;
        private System.Windows.Forms.GroupBox gbPlayerInfo;
        private System.Windows.Forms.DataGridView dgvPlayer;
        private System.Windows.Forms.Button btnSearchPlayer;
        private System.Windows.Forms.TextBox tbSearchPlayer;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbSP;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbMP;
        private System.Windows.Forms.TextBox tbZC;
        private System.Windows.Forms.TextBox tbCP;
        private System.Windows.Forms.TextBox tbHomePlace;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbFname;
        private System.Windows.Forms.TextBox tbLname;
        private System.Windows.Forms.TextBox tbPlayerId;
        private System.Windows.Forms.Button btnAddPlayer;
        private System.Windows.Forms.Label lblECPZ;
        private System.Windows.Forms.Label lblEA;
        private System.Windows.Forms.Label lblUpdatingP;
        private System.Windows.Forms.Label lblEF;
        private System.Windows.Forms.Label lblEL;
        private System.Windows.Forms.Button btnChangePid;
        private System.Windows.Forms.Button btnClearPlayer;
        private System.Windows.Forms.Panel pTeam;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgvTeam;
        private System.Windows.Forms.Button btnSearchTeam;
        private System.Windows.Forms.TextBox tbSearchTeam;
        private System.Windows.Forms.GroupBox gbTeamInfo;
        private System.Windows.Forms.Button btnClearTeam;
        private System.Windows.Forms.Button btnAddTeam;
        private System.Windows.Forms.Label eHT;
        private System.Windows.Forms.Label lblUpdateTeam;
        private System.Windows.Forms.Label eTO;
        private System.Windows.Forms.Label eTN;
        private System.Windows.Forms.Button btnChangeTid;
        private System.Windows.Forms.TextBox tbTeamHome;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbTeamOwner;
        private System.Windows.Forms.TextBox tbTeamName;
        private System.Windows.Forms.TextBox tbIdTeam;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel pARroster;
        private System.Windows.Forms.Label refreshRoster;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnRelease;
        private System.Windows.Forms.Button btnAssign;
        private System.Windows.Forms.ComboBox cbTeamRoster;
        private System.Windows.Forms.ListView lvAssignedPlayer;
        private System.Windows.Forms.ColumnHeader AssignPlayerId;
        private System.Windows.Forms.ColumnHeader AssignPlayerName;
        private System.Windows.Forms.ListView lvFreePlayer;
        private System.Windows.Forms.ColumnHeader FreePlayerId;
        private System.Windows.Forms.ColumnHeader FreePlayerName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbSearchFreeAgent;
        private System.Windows.Forms.Label lblCTP;
        private System.Windows.Forms.PictureBox pbTeamEdit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pp6;
        private System.Windows.Forms.Panel pp5;
        private System.Windows.Forms.Panel pp2;
        private System.Windows.Forms.Panel pp1;
        private System.Windows.Forms.Panel pp4;
        private System.Windows.Forms.Panel pp3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
