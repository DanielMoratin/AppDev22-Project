﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace BLS__New_
{
    public partial class wfGame : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;
        String defaultImgPath = "C:\\Users\\Daniel Gabriel\\Desktop\\2nd SEM BSIT - 2\\AppDev Leo\\Pictures\\tpp.jpg";

        public wfGame()
        {
            InitializeComponent();
        }

        private void wfGame_Load(object sender, EventArgs e)
        {
            refresh_Click(sender, e);
        }

        public void refresh_Click(object sender, EventArgs e)
        {
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "Recent Games List As Of  " + strDT;

            flpGames.Controls.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Game");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read()) {
                TheGames tg = new TheGames();
                tg.team1name.Text = dr.GetValue(1).ToString();

                SqlConnection tempCon = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                tempCon.Open();
                SqlCommand tempCmd = new SqlCommand("Select * from Team where Name = @n");
                tempCmd.Connection = tempCon;
                tempCmd.Parameters.AddWithValue("@n", dr.GetValue(1).ToString());
                SqlDataReader tempDr = tempCmd.ExecuteReader();
                while (tempDr.Read())
                {
                    try
                    {
                        byte[] img = (byte[])(tempDr.GetValue(7));
                        MemoryStream ms = new MemoryStream(img);
                        tg.pb1.Image = Image.FromStream(ms);
                    }
                    catch (Exception ex)
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(defaultImgPath, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        tg.pb1.Image = Image.FromStream(new MemoryStream(img));
                    }
                }
                tempCon.Close();

                tg.team1score.Text = "Final Score : " + dr.GetValue(2).ToString();
                tg.team2name.Text = dr.GetValue(3).ToString();

                tempCon.Open();
                tempCmd = new SqlCommand("Select * from Team where Name = @n");
                tempCmd.Connection = tempCon;
                tempCmd.Parameters.AddWithValue("@n", dr.GetValue(3).ToString());
                tempDr = tempCmd.ExecuteReader();
                while (tempDr.Read())
                {
                    try
                    {
                        byte[] img = (byte[])(tempDr.GetValue(7));
                        MemoryStream ms = new MemoryStream(img);
                        tg.pb2.Image = Image.FromStream(ms);
                    }
                    catch (Exception ex)
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(defaultImgPath, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        tg.pb2.Image = Image.FromStream(new MemoryStream(img));
                    }
                }
                tempCon.Close();

                tg.team2score.Text = "Final Score : " + dr.GetValue(4).ToString();
                tg.lblSched.Text = dr.GetValue(5).ToString();
                flpGames.Controls.Add(tg);
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show("das");
        }
    }
}
