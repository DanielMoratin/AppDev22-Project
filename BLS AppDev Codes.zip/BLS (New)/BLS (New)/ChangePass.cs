﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BLS__New_
{
    public partial class ChangePass : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;

        String user;

        public ChangePass(String u)
        {
            InitializeComponent();
            user = u;
        }

        private void ChangePass_Load(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("Select * from Admin where AdminName = @n");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@n", user);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                tbID.Text = dr.GetValue(0).ToString();
                tbUser.Text = dr.GetValue(1).ToString();
                tbPass.Text = dr.GetValue(2).ToString(); 
                tbCpass.Text = dr.GetValue(2).ToString();
            }
            con.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (tbCpass.Text == tbPass.Text) {
                con.Open();
                cmd = new SqlCommand("Update Admin Set AdminName = @name, AdminPass = @pass where AdminName = @n");
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@n", user);
                cmd.Parameters.AddWithValue("@name", tbUser.Text);
                cmd.Parameters.AddWithValue("@pass", tbPass.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                this.Close();
            }
            else
            {
                MessageBox.Show("Password not the same.","Confirm Password",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
