﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace BLS__New_
{
    public partial class wfFile : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        DataSet ds;

        Color c;

        FormBLS fb;
        public wfFile()
        {
            InitializeComponent();
        }

        private void wfFile_Load(object sender, EventArgs e)
        {
            btnChangPid_Click(sender, e);
            cbMP.SelectedIndex = 0;
            cbSP.SelectedIndex = 0;
            displayPlayer();
            btnAEP_Click(sender, e);
            btnChangeTid_Click(sender, e);
            displayTeam();
            c = tbSearchFreeAgent.ForeColor;
            displayTeamRoster();
            refreshRoster_Click(sender, e);
            strImgPath = defaultImgPath;
        }
        public void getFB(FormBLS fb)
        {
            this.fb = fb;
        }
        void displayPlayer()
        {
            con.Open();
            cmd = new SqlCommand("Select Player_Id as ID, Lname as [Last name], Fname as [First name], Team, Status from Player where concat(Player_Id, Lname, Fname, Haddress, CityProv, Zip, MainPos, SecPos)like '%'+@search+'%' And [Status] = 'Active'");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tbSearchPlayer.Text);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "Player");
            dgvPlayer.DataSource = ds.Tables[0];
            con.Close();
        }

        private void btnAEP_Click(object sender, EventArgs e)
        {
            pPlayer.Visible = true;
            pPlayer.BringToFront();
            lblTitle.Text = "Add/Edit Player";
            lblDetial.Text = "ADD new or UPDATE existing PLAYER in the system.";
            pTeam.Visible = false;
            pTeam.SendToBack();
            pARroster.Visible = false;
            pARroster.SendToBack();

            pp1.Visible = true;
            pp2.Visible = true;
            pp3.Visible = false;
            pp4.Visible = false;
            pp5.Visible = false;
            pp6.Visible = false;
        }

        Boolean idChecker(String strId)
        {
            con.Open();
            cmd = new SqlCommand("Select * from Player");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.GetValue(0).ToString() == strId)
                {
                    con.Close();
                    return true;
                }
            }
            con.Close();
            return false;
        }

        private void btnChangPid_Click(object sender, EventArgs e)
        {
            if (btnChangePid.Text == "Change") {
                Random ran = new Random();
                String strRan = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ", strResult = "PP-";
                do {
                    for (int i = 0; i < 10; i++)
                    {
                        char c = strRan.ToCharArray()[ran.Next(0, strRan.Length)];
                        strResult += c;
                    }
                } while (idChecker(strResult));
                tbPlayerId.Text = strResult;
            }
            else
            {
                if (MessageBox.Show("Do yo want to remove this player(ID: " + tbPlayerId.Text + ")?","Remove Player", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) { 
                    con.Open();
                    cmd = new SqlCommand("Update Player Set [Status] = 'Removed' Where Player_Id = '" + tbPlayerId.Text + "'");
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    btnClearPlayer_Click(sender, e);
                }
                refreshRoster_Click(sender, e);
            }
        }

        Boolean isInt(String strInt)
        {
            try
            {
                Convert.ToInt32(strInt);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            Boolean b1 = false, b2 = false, b3 = false, b4 = false; 
            if (tbLname.Text == "")
            {
                lblEL.Visible = true;
            }
            else
            {
                lblEL.Visible = false;
                b1 = true;
            }

            if (tbFname.Text == "")
            {
                lblEF.Visible = true;
            }
            else
            {
                lblEF.Visible = false;
                b2 = true;
            }

            if (tbHomePlace.Text == "")
            {
                lblEA.Visible = true;
            }
            else
            {
                lblEA.Visible = false;
                b3 = true;
            }

            if (tbCP.Text == "" || tbZC.Text == "")
            {
                lblECPZ.Visible = true;
                lblECPZ.Text = "*Error: need CITY/PROVINCE and ZIP CODE inputted*";
            }
            else
            {
                if (tbZC.Text.Length == 4 || tbZC.Text.Length == 5 || tbZC.Text.Length == 9)
                {
                    if ( isInt(tbZC.Text) ) {
                        lblECPZ.Visible = false;
                        b4 = true;
                    }
                    else
                    {
                        lblECPZ.Visible = true;
                        lblECPZ.Text = "*Error: ZIP CODE must be a group of 4, 5 or 9 numbers*";
                    }
                }
                else
                {
                    lblECPZ.Visible = true;
                    lblECPZ.Text = "*Error: ZIP CODE must be a group of 4, 5 or 9 numbers*";
                }
            }

            if (b1 && b2 && b3 && b4)
            {
                if (btnAddPlayer.Text == "Add") {
                    con.Open();
                    cmd = new SqlCommand("AddPlayer");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@id", tbPlayerId.Text);
                    cmd.Parameters.AddWithValue("@lname", tbLname.Text);
                    cmd.Parameters.AddWithValue("@fname", tbFname.Text);
                    cmd.Parameters.AddWithValue("@hadd", tbHomePlace.Text);
                    cmd.Parameters.AddWithValue("@cityProv", tbCP.Text);
                    cmd.Parameters.AddWithValue("@zip", tbZC.Text);
                    cmd.Parameters.AddWithValue("@mpos", cbMP.SelectedItem);
                    cmd.Parameters.AddWithValue("@spos", cbSP.SelectedItem);
                    cmd.Parameters.AddWithValue("@team", "Free Agent");
                    cmd.Parameters.AddWithValue("@status", "Active");
                    cmd.ExecuteNonQuery();
                    con.Close();
                    btnClearPlayer_Click(sender, e);
                }
                else
                {
                    con.Open();
                    cmd = new SqlCommand("UpdatePlayer");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@id", tbPlayerId.Text);
                    cmd.Parameters.AddWithValue("@lname", tbLname.Text);
                    cmd.Parameters.AddWithValue("@fname", tbFname.Text);
                    cmd.Parameters.AddWithValue("@hadd", tbHomePlace.Text);
                    cmd.Parameters.AddWithValue("@cityProv", tbCP.Text);
                    cmd.Parameters.AddWithValue("@zip", tbZC.Text);
                    cmd.Parameters.AddWithValue("@mpos", cbMP.SelectedItem);
                    cmd.Parameters.AddWithValue("@spos", cbSP.SelectedItem);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    btnClearPlayer_Click(sender, e);
                }
                refreshRoster_Click(sender, e);
            }
        }

        private void btnClearPlayer_Click(object sender, EventArgs e)
        {
            tbLname.Text = "";
            tbFname.Text = "";
            tbHomePlace.Text = "";
            tbCP.Text = "";
            tbZC.Text = "";
            cbMP.SelectedIndex = 0;
            cbSP.SelectedIndex = 0;
            lblEA.Visible = false;
            lblECPZ.Visible = false;
            lblEF.Visible = false;
            lblEL.Visible = false;
            lblUpdatingP.Visible = false;
            btnAddPlayer.Text = "Add";
            btnChangePid.Text = "Change";
            btnChangPid_Click(sender, e);
            displayPlayer();
            fb.refreshAll(sender, e);
        }

        private void tbSearchPlayer_TextChanged(object sender, EventArgs e)
        {
            displayPlayer();
        }

        Boolean checkTB()
        {
            if (tbLname.Text != "" || tbFname.Text != "" || tbHomePlace.Text != "" || tbCP.Text != "" || tbZC.Text != "")
            {
                if (MessageBox.Show("Updating this player will erase all information that are inputted in the text boxes. Are you sure you want to continue?", "Clear Information", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }

        private void dgvPlayer_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if ( checkTB() ) {
                con.Open();
                cmd = new SqlCommand("Select * from Player where Player_Id = '" + dgvPlayer[0, dgvPlayer.CurrentRow.Index].Value.ToString() + "'");
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    tbPlayerId.Text = dr.GetValue(0).ToString();
                    tbLname.Text = dr.GetValue(1).ToString();
                    tbFname.Text = dr.GetValue(2).ToString();
                    tbHomePlace.Text = dr.GetValue(3).ToString();
                    tbCP.Text = dr.GetValue(4).ToString();
                    tbZC.Text = dr.GetValue(5).ToString();
                    cbMP.SelectedItem = dr.GetValue(6).ToString();
                    cbSP.SelectedItem = dr.GetValue(7).ToString();
                }
                con.Close();
                lblUpdatingP.Visible = true;
                btnAddPlayer.Text = "Update";
                btnChangePid.Text = "Remove";
                lblEA.Visible = false;
                lblECPZ.Visible = false;
                lblEF.Visible = false;
                lblEL.Visible = false;
            }
        }

        private void btnEAT_Click(object sender, EventArgs e)
        {
            pTeam.Visible = true;
            pTeam.BringToFront();
            lblTitle.Text = "Add/Edit Team";
            lblDetial.Text = "ADD new or UPDATE existing TEAM in the system.";
            pPlayer.Visible = false;
            pPlayer.SendToBack();
            pARroster.Visible = false;
            pARroster.SendToBack();

            pp1.Visible = false;
            pp2.Visible = false;
            pp3.Visible = true;
            pp4.Visible = true;
            pp5.Visible = false;
            pp6.Visible = false;
        }

        void displayTeam()
        {
            con.Open();
            cmd = new SqlCommand("Select * from Team where concat(Team_Id, Name, Owner, Place, Wins, Loses)like '%'+@search+'%' And [Status] = 'Active'");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tbSearchTeam.Text);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "Player");
            dgvTeam.DataSource = ds.Tables[0];
            con.Close();
        }

        Boolean idTeamChecker(String strId)
        {
            con.Open();
            cmd = new SqlCommand("Select * from Team");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.GetValue(0).ToString() == strId)
                {
                    con.Close();
                    return true;
                }
            }
            con.Close();
            return false;
        }

        private void btnChangeTid_Click(object sender, EventArgs e)
        {
            if (btnChangeTid.Text == "Change") {
                Random ran = new Random();
                String strRan = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ", strResult = "TT-";
                do
                {
                    for (int i = 0; i < 10; i++)
                    {
                        char c = strRan.ToCharArray()[ran.Next(0, strRan.Length)];
                        strResult += c;
                    }
                } while (idTeamChecker(strResult));
                tbIdTeam.Text = strResult;
            }
            else
            {
                if (MessageBox.Show("Do yo want to remove this team(ID: " + tbIdTeam.Text + ")?", "Remove Team", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    con.Open();
                    cmd = new SqlCommand("Update Team Set [Status] = 'Removed' Where Team_Id = '" + tbIdTeam.Text + "'");
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    cmd = new SqlCommand("Update Player Set [Team] = 'Free Agent' Where Team = @team");
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@team", tbTeamName.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    btnClearTeam_Click(sender, e);
                    refreshRoster_Click(sender, e);
                    displayTeamRoster();
                }
            }
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            Boolean b1 = false, b2 = false, b3 = false;
            if (tbTeamName.Text == "")
            {
                eTN.Visible = true;
                eTN.Text = "*Error: need TEAM NAME inputted*";
            }
            else
            {
                eTN.Visible = false;
                b1 = true;
                con.Open();
                cmd = new SqlCommand("Select * from Team");
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.GetValue(1).ToString() == tbTeamName.Text && dr.GetValue(0).ToString() != tbIdTeam.Text)
                    {
                        eTN.Visible = true;
                        eTN.Text = "*Team name is already used*";
                        b1 = false;
                    }
                }
                con.Close();
            }

            if (tbTeamOwner.Text == "")
            {
                eTO.Visible = true;
            }
            else
            {
                eTO.Visible = false;
                b2 = true;
            }

            if (tbTeamHome.Text == "")
            {
                eHT.Visible = true;
            }
            else
            {
                eHT.Visible = false;
                b3 = true;
            }

            byte[] img = null;
            FileStream fs = new FileStream(strImgPath , FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);

            if (b1 && b2 && b3)
            {
                if (btnAddTeam.Text == "Add") {
                    con.Open();
                    cmd = new SqlCommand("AddTeam");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@id", tbIdTeam.Text);
                    cmd.Parameters.AddWithValue("@name", tbTeamName.Text);
                    cmd.Parameters.AddWithValue("@owner", tbTeamOwner.Text);
                    cmd.Parameters.AddWithValue("@home", tbTeamHome.Text);
                    cmd.Parameters.AddWithValue("@wins", 0);
                    cmd.Parameters.AddWithValue("@loses", 0);
                    cmd.Parameters.AddWithValue("@status", "Active");
                    cmd.Parameters.AddWithValue("img", img);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                else
                {
                    con.Open();
                    cmd = new SqlCommand("Select * from Team where Team_Id = '" + tbIdTeam.Text + "'");
                    cmd.Connection = con;
                    dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.GetValue(0).ToString() == tbIdTeam.Text && dr.GetValue(1).ToString() != tbTeamName.Text)
                        {
                            SqlConnection tempcon = new SqlConnection("Data Source = (localdb)\\ProjectsV13; Initial Catalog = dbBLS; Integrated Security = True; Connect Timeout = 30; Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                            tempcon.Open();
                            SqlCommand tempcmd = new SqlCommand("Update Player Set Team = @teamC Where Team = @team");
                            tempcmd.Connection = tempcon;
                            tempcmd.Parameters.AddWithValue("@teamC", tbTeamName.Text);
                            tempcmd.Parameters.AddWithValue("@team", dr.GetValue(1).ToString());
                            tempcmd.ExecuteNonQuery();
                            tempcon.Close();
                        }
                    }
                    con.Close();
                    con.Open();
                    cmd = new SqlCommand("UpdateTeam");
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@id", tbIdTeam.Text);
                    cmd.Parameters.AddWithValue("@name", tbTeamName.Text);
                    cmd.Parameters.AddWithValue("@owner", tbTeamOwner.Text);
                    cmd.Parameters.AddWithValue("@home", tbTeamHome.Text);
                    cmd.Parameters.AddWithValue("img", img);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                btnClearTeam_Click(sender, e);
                displayTeamRoster();
            }
        }

        private void btnClearTeam_Click(object sender, EventArgs e)
        {
            tbTeamName.Text = "";
            tbTeamOwner.Text = "";
            tbTeamHome.Text = "";
            eHT.Visible = false;
            eTO.Visible = false;
            eTN.Visible = false;
            lblUpdateTeam.Visible = false;
            btnAddTeam.Text = "Add";
            btnChangeTid.Text = "Change";
            btnChangeTid_Click(sender, e);
            displayTeam();
            fb.refreshAll(sender, e);
            byte[] img = null;
            FileStream fs = new FileStream(defaultImgPath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);
            pbTeamEdit.Image = Image.FromStream(new MemoryStream(img));
        }

        private void tbSearchTeam_TextChanged(object sender, EventArgs e)
        {
            displayTeam();
        }

        Boolean checkTBteam()
        {
            if (tbTeamName.Text != "" || tbTeamOwner.Text != "" || tbTeamHome.Text != "")
            {
                if (MessageBox.Show("Updating this team will erase all information that are inputted in the text boxes. Are you sure you want to continue?", "Clear Information", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }

        private void dgvTeam_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (checkTBteam())
            {
                con.Open();
                cmd = new SqlCommand("Select * from Team where Team_Id = '" + dgvTeam[0, dgvTeam.CurrentRow.Index].Value.ToString() + "'");
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    tbIdTeam.Text = dr.GetValue(0).ToString();
                    tbTeamName.Text = dr.GetValue(1).ToString();
                    tbTeamOwner.Text = dr.GetValue(2).ToString();
                    tbTeamHome.Text = dr.GetValue(3).ToString();
                    try
                    {
                        byte[] img = (byte[])(dr.GetValue(7));
                        MemoryStream ms = new MemoryStream(img);
                        pbTeamEdit.Image = Image.FromStream(ms);
                    }
                    catch (Exception ex)
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(defaultImgPath, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        pbTeamEdit.Image = Image.FromStream(new MemoryStream(img));
                    }
                }
                con.Close();
                lblUpdateTeam.Visible = true;
                btnAddTeam.Text = "Update";
                btnChangeTid.Text = "Remove";
                eHT.Visible = false;
                eTO.Visible = false;
                eTN.Visible = false;
            }
        }

        private void btnARR_Click(object sender, EventArgs e)
        {
            pARroster.Visible = true;
            pARroster.BringToFront();
            lblTitle.Text = "Assign/Release Roster";
            lblDetial.Text = "ASSIGN or RELEASE existing PLAYER to a TEAM in the system.";
            pPlayer.Visible = false;
            pPlayer.SendToBack();
            pTeam.Visible = false;
            pTeam.SendToBack();

            pp1.Visible = false;
            pp2.Visible = false;
            pp3.Visible = false;
            pp4.Visible = false;
            pp5.Visible = true;
            pp6.Visible = true;
        }

        private void refreshRoster_Click(object sender, EventArgs e)
        {
            tbSearchFreeAgent_TextChanged(sender, e);
            cbTeamRoster_SelectedIndexChanged(sender, e);
        }

        private void tbSearchFreeAgent_TextChanged(object sender, EventArgs e)
        {
            String search = tbSearchFreeAgent.Text;
            if (search == "Search Player") search = "";
            lvFreePlayer.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Player Where Team = 'Free Agent' and [Status] = 'Active' and concat(Player_Id, Lname, Fname)like '%' + @search + '%'");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", search);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemi = dr.GetValue(0).ToString();
                String itemn = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                String[] iRow = { itemi, itemn };
                ListViewItem lviRow = new ListViewItem(iRow);
                lvFreePlayer.Items.Add(lviRow);
            }
            con.Close();
        }
        private void cbTeamRoster_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("CountTeam");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = con;
            int cntTeam = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            lvAssignedPlayer.Items.Clear();
            if (cntTeam != 0) {
                con.Open();
                cmd = new SqlCommand("Select * from Player Where Team = @team and [Status] = 'Active'");
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@team", cbTeamRoster.SelectedItem);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    String itemi = dr.GetValue(0).ToString();
                    String itemn = dr.GetValue(1).ToString() + ", " + dr.GetValue(2).ToString();
                    String[] iRow = { itemi, itemn };
                    ListViewItem lviRow = new ListViewItem(iRow);
                    lvAssignedPlayer.Items.Add(lviRow);
                }
                con.Close();
            }
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            if (lvFreePlayer.SelectedItems.Count > 0) {
                if (cbTeamRoster.SelectedItem != null) {
                    con.Open();
                    cmd = new SqlCommand("Update Player Set Team = @team Where Player_Id = '" + lvFreePlayer.SelectedItems[0].SubItems[0].Text + "'");
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@team", cbTeamRoster.SelectedItem);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    refreshRoster_Click(sender, e);
                    fb.refreshAll(sender, e);
                }
                else
                    MessageBox.Show("Please input a team to assign a player", "No Team", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Please select a free agent player to assign it to a team","Select Player", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            if (lvAssignedPlayer.SelectedItems.Count > 0)
            {
                con.Open();
                cmd = new SqlCommand("Update Player Set Team = 'Free Agent' Where Player_Id = '" + lvAssignedPlayer.SelectedItems[0].SubItems[0].Text + "'");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
                tbSearchFreeAgent.Text = "";
                refreshRoster_Click(sender, e);
                fb.refreshAll(sender, e);
            }
            else
            {
                MessageBox.Show("Please select a assigned player to release it to a team", "Select Player", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void displayTeamRoster()
        {
            int cnt = 0;
            cbTeamRoster.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Team Where [Status] = 'Active'");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cbTeamRoster.Items.Add(dr.GetValue(1).ToString());
                cnt++;
            }
            con.Close();
            if (cnt != 0) cbTeamRoster.SelectedIndex = 0;
        }

        private void tbSearchFreeAgent_Enter(object sender, EventArgs e)
        {
            if (tbSearchFreeAgent.Text == "Search Player")
            {
                tbSearchFreeAgent.Text = "";
                tbSearchFreeAgent.ForeColor = Color.Black;
            }
        }

        private void tbSearchFreeAgent_Leave(object sender, EventArgs e)
        {
            if (tbSearchFreeAgent.Text == "")
            {
                tbSearchFreeAgent.Text = "Search Player";
                tbSearchFreeAgent.ForeColor = c;
            }
            else
            {
                tbSearchFreeAgent.ForeColor = Color.Black;
            }
        }

        private void pbTeamEdit_MouseHover(object sender, EventArgs e)
        {
            lblCTP.Visible = true;
        }

        private void pbTeamEdit_MouseLeave(object sender, EventArgs e)
        {
            lblCTP.Visible = false;
        }

        String defaultImgPath = "C:\\Users\\Daniel Gabriel\\Desktop\\2nd SEM BSIT - 2\\AppDev Leo\\Pictures\\tpp.jpg";
        String strImgPath = "";
        private void pbTeamEdit_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "All files(*.*)|*.*|png files(*.png)|.png|jpg files(*.jpg)|*.jpg";
            ofd.ValidateNames = true;
            ofd.Multiselect = false;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                strImgPath = ofd.FileName.ToString();
                pbTeamEdit.Image = Image.FromFile(ofd.FileName);
            }
        }
    }
}
