﻿namespace BLS__New_
{
    partial class wfPlayer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wfPlayer));
            this.pHeader = new System.Windows.Forms.Panel();
            this.lblDetial = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnAP = new System.Windows.Forms.Button();
            this.btnFA = new System.Windows.Forms.Button();
            this.btnCP = new System.Windows.Forms.Button();
            this.pAP = new System.Windows.Forms.Panel();
            this.btnSearchAP = new System.Windows.Forms.Button();
            this.tbSearchAP = new System.Windows.Forms.TextBox();
            this.cbAPsort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lvAP = new System.Windows.Forms.ListView();
            this.lvPlayerId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvHomePlace = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvTeam = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refresh1 = new System.Windows.Forms.Label();
            this.pCP = new System.Windows.Forms.Panel();
            this.btnSearchCP = new System.Windows.Forms.Button();
            this.tbSearchCP = new System.Windows.Forms.TextBox();
            this.cbSortCP = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lvCP = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refreshCP = new System.Windows.Forms.Label();
            this.pFA = new System.Windows.Forms.Panel();
            this.btnSearchFA = new System.Windows.Forms.Button();
            this.tbSearchFA = new System.Windows.Forms.TextBox();
            this.lvFA = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refreshFA = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pp1 = new System.Windows.Forms.Panel();
            this.pp2 = new System.Windows.Forms.Panel();
            this.pp4 = new System.Windows.Forms.Panel();
            this.pp3 = new System.Windows.Forms.Panel();
            this.pp6 = new System.Windows.Forms.Panel();
            this.pp5 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pHeader.SuspendLayout();
            this.pAP.SuspendLayout();
            this.pCP.SuspendLayout();
            this.pFA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pHeader
            // 
            this.pHeader.Controls.Add(this.pictureBox2);
            this.pHeader.Controls.Add(this.pp6);
            this.pHeader.Controls.Add(this.pp5);
            this.pHeader.Controls.Add(this.pp4);
            this.pHeader.Controls.Add(this.pp3);
            this.pHeader.Controls.Add(this.pp2);
            this.pHeader.Controls.Add(this.pp1);
            this.pHeader.Controls.Add(this.panel2);
            this.pHeader.Controls.Add(this.panel1);
            this.pHeader.Controls.Add(this.lblDetial);
            this.pHeader.Controls.Add(this.lblTitle);
            this.pHeader.Controls.Add(this.btnAP);
            this.pHeader.Controls.Add(this.btnFA);
            this.pHeader.Controls.Add(this.btnCP);
            this.pHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pHeader.Location = new System.Drawing.Point(0, 0);
            this.pHeader.Name = "pHeader";
            this.pHeader.Size = new System.Drawing.Size(686, 100);
            this.pHeader.TabIndex = 4;
            // 
            // lblDetial
            // 
            this.lblDetial.AutoSize = true;
            this.lblDetial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetial.Location = new System.Drawing.Point(54, 46);
            this.lblDetial.Name = "lblDetial";
            this.lblDetial.Size = new System.Drawing.Size(253, 15);
            this.lblDetial.TabIndex = 4;
            this.lblDetial.Text = "All Players List As Of MM/dd/yyyy  hh:mm:ss  tt";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(35, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(404, 34);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "BASKETBALL LEAGUE SYSTEM PLAYERS";
            // 
            // btnAP
            // 
            this.btnAP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnAP.FlatAppearance.BorderSize = 0;
            this.btnAP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAP.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAP.ForeColor = System.Drawing.Color.White;
            this.btnAP.Location = new System.Drawing.Point(88, 66);
            this.btnAP.Name = "btnAP";
            this.btnAP.Size = new System.Drawing.Size(106, 31);
            this.btnAP.TabIndex = 0;
            this.btnAP.Text = "All Player";
            this.btnAP.UseVisualStyleBackColor = false;
            this.btnAP.Click += new System.EventHandler(this.btnAP_Click);
            // 
            // btnFA
            // 
            this.btnFA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnFA.FlatAppearance.BorderSize = 0;
            this.btnFA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFA.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFA.ForeColor = System.Drawing.Color.White;
            this.btnFA.Location = new System.Drawing.Point(431, 66);
            this.btnFA.Name = "btnFA";
            this.btnFA.Size = new System.Drawing.Size(106, 31);
            this.btnFA.TabIndex = 2;
            this.btnFA.Text = "Free Agent";
            this.btnFA.UseVisualStyleBackColor = false;
            this.btnFA.Click += new System.EventHandler(this.btnFA_Click);
            // 
            // btnCP
            // 
            this.btnCP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnCP.FlatAppearance.BorderSize = 0;
            this.btnCP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCP.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCP.ForeColor = System.Drawing.Color.White;
            this.btnCP.Location = new System.Drawing.Point(254, 66);
            this.btnCP.Name = "btnCP";
            this.btnCP.Size = new System.Drawing.Size(106, 31);
            this.btnCP.TabIndex = 1;
            this.btnCP.Text = "Contract Player";
            this.btnCP.UseVisualStyleBackColor = false;
            this.btnCP.Click += new System.EventHandler(this.btnCP_Click);
            // 
            // pAP
            // 
            this.pAP.AutoScroll = true;
            this.pAP.Controls.Add(this.btnSearchAP);
            this.pAP.Controls.Add(this.tbSearchAP);
            this.pAP.Controls.Add(this.cbAPsort);
            this.pAP.Controls.Add(this.label1);
            this.pAP.Controls.Add(this.lvAP);
            this.pAP.Controls.Add(this.refresh1);
            this.pAP.Location = new System.Drawing.Point(3, 103);
            this.pAP.Name = "pAP";
            this.pAP.Size = new System.Drawing.Size(680, 344);
            this.pAP.TabIndex = 5;
            // 
            // btnSearchAP
            // 
            this.btnSearchAP.Location = new System.Drawing.Point(314, 5);
            this.btnSearchAP.Name = "btnSearchAP";
            this.btnSearchAP.Size = new System.Drawing.Size(75, 24);
            this.btnSearchAP.TabIndex = 5;
            this.btnSearchAP.Text = "Find player";
            this.btnSearchAP.UseVisualStyleBackColor = true;
            this.btnSearchAP.Click += new System.EventHandler(this.btnSearchAP_Click);
            // 
            // tbSearchAP
            // 
            this.tbSearchAP.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSearchAP.Location = new System.Drawing.Point(390, 7);
            this.tbSearchAP.Name = "tbSearchAP";
            this.tbSearchAP.Size = new System.Drawing.Size(100, 20);
            this.tbSearchAP.TabIndex = 4;
            this.tbSearchAP.Text = "Search Player";
            this.tbSearchAP.TextChanged += new System.EventHandler(this.tbSearchAP_TextChanged);
            this.tbSearchAP.Enter += new System.EventHandler(this.tbSearchAP_Enter);
            this.tbSearchAP.Leave += new System.EventHandler(this.tbSearchAP_Leave);
            // 
            // cbAPsort
            // 
            this.cbAPsort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAPsort.FormattingEnabled = true;
            this.cbAPsort.Items.AddRange(new object[] {
            "Name",
            "Team"});
            this.cbAPsort.Location = new System.Drawing.Point(68, 6);
            this.cbAPsort.Name = "cbAPsort";
            this.cbAPsort.Size = new System.Drawing.Size(121, 21);
            this.cbAPsort.TabIndex = 3;
            this.cbAPsort.SelectedIndexChanged += new System.EventHandler(this.cbAPsort_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sort by : ";
            // 
            // lvAP
            // 
            this.lvAP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvAP.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvPlayerId,
            this.lvName,
            this.lvHomePlace,
            this.lvTeam});
            this.lvAP.FullRowSelect = true;
            this.lvAP.GridLines = true;
            this.lvAP.HideSelection = false;
            this.lvAP.Location = new System.Drawing.Point(14, 31);
            this.lvAP.MultiSelect = false;
            this.lvAP.Name = "lvAP";
            this.lvAP.Size = new System.Drawing.Size(653, 298);
            this.lvAP.TabIndex = 1;
            this.lvAP.UseCompatibleStateImageBehavior = false;
            this.lvAP.View = System.Windows.Forms.View.Details;
            this.lvAP.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lvAP_MouseDoubleClick);
            // 
            // lvPlayerId
            // 
            this.lvPlayerId.Text = "ID";
            this.lvPlayerId.Width = 115;
            // 
            // lvName
            // 
            this.lvName.Text = "Name";
            this.lvName.Width = 187;
            // 
            // lvHomePlace
            // 
            this.lvHomePlace.Text = "Home Place";
            this.lvHomePlace.Width = 202;
            // 
            // lvTeam
            // 
            this.lvTeam.Text = "Team";
            this.lvTeam.Width = 138;
            // 
            // refresh1
            // 
            this.refresh1.AutoSize = true;
            this.refresh1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh1.ForeColor = System.Drawing.Color.Blue;
            this.refresh1.Location = new System.Drawing.Point(623, 9);
            this.refresh1.Name = "refresh1";
            this.refresh1.Size = new System.Drawing.Size(44, 13);
            this.refresh1.TabIndex = 0;
            this.refresh1.Text = "Refresh";
            this.refresh1.Click += new System.EventHandler(this.refresh1_Click);
            // 
            // pCP
            // 
            this.pCP.AutoScroll = true;
            this.pCP.Controls.Add(this.btnSearchCP);
            this.pCP.Controls.Add(this.tbSearchCP);
            this.pCP.Controls.Add(this.cbSortCP);
            this.pCP.Controls.Add(this.label2);
            this.pCP.Controls.Add(this.lvCP);
            this.pCP.Controls.Add(this.refreshCP);
            this.pCP.Location = new System.Drawing.Point(3, 103);
            this.pCP.Name = "pCP";
            this.pCP.Size = new System.Drawing.Size(680, 344);
            this.pCP.TabIndex = 6;
            // 
            // btnSearchCP
            // 
            this.btnSearchCP.Location = new System.Drawing.Point(314, 5);
            this.btnSearchCP.Name = "btnSearchCP";
            this.btnSearchCP.Size = new System.Drawing.Size(75, 24);
            this.btnSearchCP.TabIndex = 5;
            this.btnSearchCP.Text = "Find player";
            this.btnSearchCP.UseVisualStyleBackColor = true;
            this.btnSearchCP.Click += new System.EventHandler(this.btnSearchCP_Click);
            // 
            // tbSearchCP
            // 
            this.tbSearchCP.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSearchCP.Location = new System.Drawing.Point(390, 7);
            this.tbSearchCP.Name = "tbSearchCP";
            this.tbSearchCP.Size = new System.Drawing.Size(100, 20);
            this.tbSearchCP.TabIndex = 4;
            this.tbSearchCP.Text = "Search Player";
            this.tbSearchCP.TextChanged += new System.EventHandler(this.tbSearchCP_TextChanged);
            this.tbSearchCP.Enter += new System.EventHandler(this.tbSearchCP_Enter);
            this.tbSearchCP.Leave += new System.EventHandler(this.tbSearchCP_Leave);
            // 
            // cbSortCP
            // 
            this.cbSortCP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSortCP.FormattingEnabled = true;
            this.cbSortCP.Items.AddRange(new object[] {
            "Name",
            "Team"});
            this.cbSortCP.Location = new System.Drawing.Point(68, 6);
            this.cbSortCP.Name = "cbSortCP";
            this.cbSortCP.Size = new System.Drawing.Size(121, 21);
            this.cbSortCP.TabIndex = 3;
            this.cbSortCP.SelectedIndexChanged += new System.EventHandler(this.cbSortrCP_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Sort by : ";
            // 
            // lvCP
            // 
            this.lvCP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvCP.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvCP.FullRowSelect = true;
            this.lvCP.GridLines = true;
            this.lvCP.HideSelection = false;
            this.lvCP.Location = new System.Drawing.Point(14, 31);
            this.lvCP.MultiSelect = false;
            this.lvCP.Name = "lvCP";
            this.lvCP.Size = new System.Drawing.Size(653, 298);
            this.lvCP.TabIndex = 1;
            this.lvCP.UseCompatibleStateImageBehavior = false;
            this.lvCP.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 115;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            this.columnHeader2.Width = 187;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Home Place";
            this.columnHeader3.Width = 202;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Team";
            this.columnHeader4.Width = 138;
            // 
            // refreshCP
            // 
            this.refreshCP.AutoSize = true;
            this.refreshCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshCP.ForeColor = System.Drawing.Color.Blue;
            this.refreshCP.Location = new System.Drawing.Point(623, 9);
            this.refreshCP.Name = "refreshCP";
            this.refreshCP.Size = new System.Drawing.Size(44, 13);
            this.refreshCP.TabIndex = 0;
            this.refreshCP.Text = "Refresh";
            this.refreshCP.Click += new System.EventHandler(this.refreshCP_Click);
            // 
            // pFA
            // 
            this.pFA.AutoScroll = true;
            this.pFA.Controls.Add(this.btnSearchFA);
            this.pFA.Controls.Add(this.tbSearchFA);
            this.pFA.Controls.Add(this.lvFA);
            this.pFA.Controls.Add(this.refreshFA);
            this.pFA.Location = new System.Drawing.Point(3, 103);
            this.pFA.Name = "pFA";
            this.pFA.Size = new System.Drawing.Size(680, 344);
            this.pFA.TabIndex = 7;
            // 
            // btnSearchFA
            // 
            this.btnSearchFA.Location = new System.Drawing.Point(314, 5);
            this.btnSearchFA.Name = "btnSearchFA";
            this.btnSearchFA.Size = new System.Drawing.Size(75, 24);
            this.btnSearchFA.TabIndex = 5;
            this.btnSearchFA.Text = "Find player";
            this.btnSearchFA.UseVisualStyleBackColor = true;
            this.btnSearchFA.Click += new System.EventHandler(this.btnSearchFA_Click);
            // 
            // tbSearchFA
            // 
            this.tbSearchFA.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSearchFA.Location = new System.Drawing.Point(390, 7);
            this.tbSearchFA.Name = "tbSearchFA";
            this.tbSearchFA.Size = new System.Drawing.Size(100, 20);
            this.tbSearchFA.TabIndex = 4;
            this.tbSearchFA.Text = "Search Player";
            this.tbSearchFA.TextChanged += new System.EventHandler(this.tbSearchFA_TextChanged);
            this.tbSearchFA.Enter += new System.EventHandler(this.tbSearchFA_Enter);
            this.tbSearchFA.Leave += new System.EventHandler(this.tbSearchFA_Leave);
            // 
            // lvFA
            // 
            this.lvFA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvFA.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.lvFA.FullRowSelect = true;
            this.lvFA.GridLines = true;
            this.lvFA.HideSelection = false;
            this.lvFA.Location = new System.Drawing.Point(14, 31);
            this.lvFA.MultiSelect = false;
            this.lvFA.Name = "lvFA";
            this.lvFA.Size = new System.Drawing.Size(653, 298);
            this.lvFA.TabIndex = 1;
            this.lvFA.UseCompatibleStateImageBehavior = false;
            this.lvFA.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "ID";
            this.columnHeader5.Width = 115;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Name";
            this.columnHeader6.Width = 187;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Home Place";
            this.columnHeader7.Width = 202;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Team";
            this.columnHeader8.Width = 138;
            // 
            // refreshFA
            // 
            this.refreshFA.AutoSize = true;
            this.refreshFA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshFA.ForeColor = System.Drawing.Color.Blue;
            this.refreshFA.Location = new System.Drawing.Point(623, 9);
            this.refreshFA.Name = "refreshFA";
            this.refreshFA.Size = new System.Drawing.Size(44, 13);
            this.refreshFA.TabIndex = 0;
            this.refreshFA.Text = "Refresh";
            this.refreshFA.Click += new System.EventHandler(this.refreshFA_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(0, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(686, 3);
            this.panel2.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(686, 1);
            this.panel1.TabIndex = 14;
            // 
            // pp1
            // 
            this.pp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp1.Location = new System.Drawing.Point(88, 66);
            this.pp1.Name = "pp1";
            this.pp1.Size = new System.Drawing.Size(10, 28);
            this.pp1.TabIndex = 16;
            // 
            // pp2
            // 
            this.pp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp2.Location = new System.Drawing.Point(184, 66);
            this.pp2.Name = "pp2";
            this.pp2.Size = new System.Drawing.Size(10, 28);
            this.pp2.TabIndex = 17;
            // 
            // pp4
            // 
            this.pp4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp4.Location = new System.Drawing.Point(350, 66);
            this.pp4.Name = "pp4";
            this.pp4.Size = new System.Drawing.Size(10, 28);
            this.pp4.TabIndex = 19;
            this.pp4.Visible = false;
            // 
            // pp3
            // 
            this.pp3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp3.Location = new System.Drawing.Point(254, 66);
            this.pp3.Name = "pp3";
            this.pp3.Size = new System.Drawing.Size(10, 28);
            this.pp3.TabIndex = 18;
            this.pp3.Visible = false;
            // 
            // pp6
            // 
            this.pp6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp6.Location = new System.Drawing.Point(527, 66);
            this.pp6.Name = "pp6";
            this.pp6.Size = new System.Drawing.Size(10, 28);
            this.pp6.TabIndex = 21;
            this.pp6.Visible = false;
            // 
            // pp5
            // 
            this.pp5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp5.Location = new System.Drawing.Point(431, 66);
            this.pp5.Name = "pp5";
            this.pp5.Size = new System.Drawing.Size(10, 28);
            this.pp5.TabIndex = 20;
            this.pp5.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(580, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(103, 89);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // wfPlayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.pFA);
            this.Controls.Add(this.pCP);
            this.Controls.Add(this.pAP);
            this.Controls.Add(this.pHeader);
            this.Name = "wfPlayer";
            this.Size = new System.Drawing.Size(686, 450);
            this.Load += new System.EventHandler(this.wfPlayer_Load);
            this.pHeader.ResumeLayout(false);
            this.pHeader.PerformLayout();
            this.pAP.ResumeLayout(false);
            this.pAP.PerformLayout();
            this.pCP.ResumeLayout(false);
            this.pCP.PerformLayout();
            this.pFA.ResumeLayout(false);
            this.pFA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pHeader;
        private System.Windows.Forms.Label lblDetial;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnAP;
        private System.Windows.Forms.Button btnFA;
        private System.Windows.Forms.Button btnCP;
        private System.Windows.Forms.Panel pAP;
        private System.Windows.Forms.Label refresh1;
        private System.Windows.Forms.ListView lvAP;
        private System.Windows.Forms.ColumnHeader lvPlayerId;
        private System.Windows.Forms.ColumnHeader lvName;
        private System.Windows.Forms.ColumnHeader lvHomePlace;
        private System.Windows.Forms.ColumnHeader lvTeam;
        private System.Windows.Forms.TextBox tbSearchAP;
        private System.Windows.Forms.ComboBox cbAPsort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearchAP;
        private System.Windows.Forms.Panel pCP;
        private System.Windows.Forms.Button btnSearchCP;
        private System.Windows.Forms.TextBox tbSearchCP;
        private System.Windows.Forms.ListView lvCP;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label refreshCP;
        private System.Windows.Forms.ComboBox cbSortCP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pFA;
        private System.Windows.Forms.Button btnSearchFA;
        private System.Windows.Forms.TextBox tbSearchFA;
        private System.Windows.Forms.ListView lvFA;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Label refreshFA;
        private System.Windows.Forms.Panel pp6;
        private System.Windows.Forms.Panel pp5;
        private System.Windows.Forms.Panel pp4;
        private System.Windows.Forms.Panel pp3;
        private System.Windows.Forms.Panel pp2;
        private System.Windows.Forms.Panel pp1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
