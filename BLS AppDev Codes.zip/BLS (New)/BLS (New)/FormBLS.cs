﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS__New_
{
    public partial class FormBLS : Form
    {
        public FormBLS()
        {
            InitializeComponent();
        }

        private void FormBLS_Load(object sender, EventArgs e)
        {
            ucLogin1.getForm(this);
            wfFile1.getFB(this);
            wfPostGame1.getFB(this);
            wfPlayer1.Visible = false;
            wfFile1.Visible = false;
            wfTeam.Visible = false;
            wfPostGame1.Visible = false;
            wfStanding1.Visible = false;
            wfGame1.Visible = false;
            wfStanding1.refresh_Click(sender, e);
        }
        public void refreshAll(object sender, EventArgs e)
        {
            wfPlayer1.refresh1_Click(sender, e);
            wfPlayer1.refreshCP_Click(sender, e);
            wfPlayer1.refreshFA_Click(sender, e);
            wfTeam.refresh1_Click(sender, e);
            wfTeam.displayTeamName();
            wfStanding1.refresh_Click(sender, e);
            wfPostGame1.refresh_Click(sender, e);
            wfGame1.refresh_Click(sender, e);
        }
        private void btnP_Click(object sender, EventArgs e)
        {
            wfPlayer1.Visible = true;
            wfPlayer1.BringToFront();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
            wfTeam.Visible = false;
            wfTeam.SendToBack();
            wfPostGame1.Visible = false;
            wfPostGame1.SendToBack();
            wfStanding1.Visible = false;
            wfStanding1.SendToBack();
            wfGame1.Visible = false;
            wfGame1.SendToBack();
            wfMainMenu1.Visible = false;
            wfMainMenu1.SendToBack();

            pClick.Location = new Point(0, 171);
            pClick.Visible = true;
        }

        private void btnF_Click(object sender, EventArgs e)
        {
            wfFile1.Visible = true; 
            wfFile1.BringToFront();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
            wfTeam.Visible = false;
            wfTeam.SendToBack();
            wfPostGame1.Visible = false;
            wfPostGame1.SendToBack();
            wfStanding1.Visible = false;
            wfStanding1.SendToBack();
            wfGame1.Visible = false;
            wfGame1.SendToBack();
            wfMainMenu1.Visible = false;
            wfMainMenu1.SendToBack();

            pClick.Location = new Point(0, 243);
            pClick.Visible = true;
        }

        private void btnT_Click(object sender, EventArgs e)
        {
            wfTeam.Visible = true;
            wfTeam.BringToFront();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
            wfPostGame1.Visible = false;
            wfPostGame1.SendToBack();
            wfStanding1.Visible = false;
            wfStanding1.SendToBack();
            wfGame1.Visible = false;
            wfGame1.SendToBack();
            wfMainMenu1.Visible = false;
            wfMainMenu1.SendToBack();

            pClick.Location = new Point(0, 207);
            pClick.Visible = true;
        }

        private void btnG_Click(object sender, EventArgs e)
        {
            wfPostGame1.Visible = true;
            wfPostGame1.BringToFront();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
            wfTeam.Visible = false;
            wfTeam.SendToBack();
            wfStanding1.Visible = false;
            wfStanding1.SendToBack();
            wfGame1.Visible = false;
            wfGame1.SendToBack();
            wfMainMenu1.Visible = false;
            wfMainMenu1.SendToBack();

            pClick.Location = new Point(0, 279);
            pClick.Visible = true;
        }

        private void btnStand_Click(object sender, EventArgs e)
        {
            wfStanding1.Visible = true;
            wfStanding1.BringToFront();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
            wfTeam.Visible = false;
            wfTeam.SendToBack();
            wfPostGame1.Visible = false;
            wfPostGame1.SendToBack();
            wfGame1.Visible = false;
            wfGame1.SendToBack();
            wfMainMenu1.Visible = false;
            wfMainMenu1.SendToBack();

            pClick.Location = new Point(0, 135);
            pClick.Visible = true;
        }

        private void btnGs_Click(object sender, EventArgs e)
        {
            wfGame1.Visible = true;
            wfGame1.BringToFront();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
            wfTeam.Visible = false;
            wfTeam.SendToBack();
            wfPostGame1.Visible = false;
            wfPostGame1.SendToBack();
            wfStanding1.Visible = false;
            wfStanding1.SendToBack();
            wfMainMenu1.Visible = false;
            wfMainMenu1.SendToBack();

            pClick.Location = new Point(0, 99);
            pClick.Visible = true;
        }

        public void btnMM_Click(object sender, EventArgs e)
        {
            wfMainMenu1.Visible = true;
            wfMainMenu1.BringToFront();
            wfGame1.Visible = false;
            wfGame1.SendToBack();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
            wfTeam.Visible = false;
            wfTeam.SendToBack();
            wfPostGame1.Visible = false;
            wfPostGame1.SendToBack();
            wfStanding1.Visible = false;
            wfStanding1.SendToBack();

            pClick.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            btnMM_Click(sender, e);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        String Username = "";
        public void loginAdmin(String name)
        {
            Username = name;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            ChangePass cp = new ChangePass(Username);
            cp.ShowDialog();
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            ucLogin1.Visible = true;
            ucLogin1.BringToFront();
        }

        public void closeLogin()
        {
            ucLogin1.Visible = false;
            ucLogin1.SendToBack();
        }
    }
}
