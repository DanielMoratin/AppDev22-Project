﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BLS__New_
{
    public partial class wfTeam : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;

        Color c;
        public wfTeam()
        {
            InitializeComponent();
        }

        private void wfTeam_Load(object sender, EventArgs e)
        {
            refresh1_Click(sender, e);
            cbATsort.SelectedIndex = 0;
            btnAT_Click(sender, e);
            displayTeamName();
            c = tbSP.ForeColor;
        }

        private void btnAT_Click(object sender, EventArgs e)
        {
            pAT.Visible = true;
            pAT.BringToFront();
            pTR.Visible = false;
            pTR.SendToBack();
            lblTitle.Text = "BASKETBALL LEAGUE SYSTEM TEAMS";
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "Active Teams List As Of " + strDT;

            pp1.Visible = true;
            pp2.Visible = true;
            pp5.Visible = false;
            pp6.Visible = false;
        }

        public void refresh1_Click(object sender, EventArgs e)
        {
            lvAT.Items.Clear();
            con.Open();
            if (cbATsort.SelectedItem + "" == "Name") cmd = new SqlCommand("Select * from Team Where [Status] = 'Active' Order by Name");
            else cmd = new SqlCommand("Select * from Team Where [Status] = 'Active' Order by Owner");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString();
                String itemOwner = dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString();
                String[] iRow = { itemI, itemName, itemOwner, itemPlace };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvAT.Items.Add(itemRow);
            }
            con.Close();
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "Active Teams List As Of " + strDT;
        }

        private void cbATsort_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh1_Click(sender, e);
        }

        private void tbSearchAT_TextChanged(object sender, EventArgs e)
        {
            String tempS = tbSearchAT.Text;
            if (tempS == "Search Team") tempS = "";
            lvAT.Items.Clear();
            con.Open();
            if (cbATsort.SelectedItem + "" == "Name") cmd = new SqlCommand("Select * from Team Where [Status] = 'Active' and concat(Team_Id, Name, Owner, Place)like '%'+@search+'%' Order by Name");
            else cmd = new SqlCommand("Select * from Team Where [Status] = 'Active' and concat(Team_Id, Name, Owner, Place)like '%'+@search+'%' Order by Owner");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tempS);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemI = dr.GetValue(0).ToString();
                String itemName = dr.GetValue(1).ToString();
                String itemOwner = dr.GetValue(2).ToString();
                String itemPlace = dr.GetValue(3).ToString();
                String[] iRow = { itemI, itemName, itemOwner, itemPlace };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvAT.Items.Add(itemRow);
            }
            con.Close();
        }

        private void btnSearchAT_Click(object sender, EventArgs e)
        {
            tbSearchAT_TextChanged(sender, e);
        }

        private void tbSearchAT_Enter(object sender, EventArgs e)
        {
            if (tbSearchAT.Text == "Search Team")
            {
                tbSearchAT.Text = "";
                tbSearchAT.ForeColor = Color.Black;
            }
        }

        private void tbSearchAT_Leave(object sender, EventArgs e)
        {
            if (tbSearchAT.Text == "")
            {
                tbSearchAT.Text = "Search Team";
                tbSearchAT.ForeColor = c;
            }
            else
            {
                tbSearchAT.ForeColor = Color.Black;
            }
        }

        private void btnTR_Click(object sender, EventArgs e)
        {
            pTR.Visible = true;
            pTR.BringToFront();
            pAT.Visible = false;
            pAT.SendToBack();
            lblTitle.Text = "BASKETBALL LEAGUE SYSTEM TEAM'S ROSTER";
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lblDetial.Text = "Active Teams Roster List As Of " + strDT;

            pp1.Visible = false;
            pp2.Visible = false;
            pp5.Visible = true;
            pp6.Visible = true;
        }

        public void displayTeamName()
        {
            int cnt = 0;
            cbTeamName.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Team Where [Status] = 'Active'");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cbTeamName.Items.Add(dr.GetValue(1).ToString());
                cnt++;
            }
            con.Close();
            if (cnt != 0) cbTeamName.SelectedIndex = 0;
        }

        private void cbTeamName_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("CountPlayerInTeam");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@team", cbTeamName.SelectedItem);
            int cntTeam = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            lvTR.Items.Clear();
            if (cntTeam != 0)
            {
                con.Open();
                cmd = new SqlCommand("Select * from Player Where Team = @team and [Status] = 'Active'");
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@team", cbTeamName.SelectedItem);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    String itemln = dr.GetValue(1).ToString();
                    String itemfn = dr.GetValue(2).ToString();
                    String itempp = dr.GetValue(6).ToString();
                    String itemsp = dr.GetValue(7).ToString();
                    String[] iRow = { itemln, itemfn, itempp, itemsp };
                    ListViewItem lviRow = new ListViewItem(iRow);
                    lvTR.Items.Add(lviRow);
                }
                con.Close();
            }
        }

        private void refresh2_Click(object sender, EventArgs e)
        {
            cbTeamName_SelectedIndexChanged(sender, e);
        }

        private void tbSP_TextChanged(object sender, EventArgs e)
        {
            String tempS = tbSP.Text;
            if (tempS == "Search Team") tempS = "";
            lvTR.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Player Where concat(Player_Id, Lname, Fname, MainPos, SecPos)like '%'+@search+'%' and Team = @team and [Status] = 'Active'");
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@search", tempS);
            cmd.Parameters.AddWithValue("@team", cbTeamName.SelectedItem);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemln = dr.GetValue(1).ToString();
                String itemfn = dr.GetValue(2).ToString();
                String itempp = dr.GetValue(6).ToString();
                String itemsp = dr.GetValue(7).ToString();
                String[] iRow = { itemln, itemfn, itempp, itemsp };
                ListViewItem lviRow = new ListViewItem(iRow);
                lvTR.Items.Add(lviRow);
            }
            con.Close();
        }

        private void tbSP_Enter(object sender, EventArgs e)
        {
            if (tbSP.Text == "Search Player")
            {
                tbSP.Text = "";
                tbSP.ForeColor = Color.Black;
            }
        }

        private void tbSP_Leave(object sender, EventArgs e)
        {
            if (tbSP.Text == "")
            {
                tbSP.Text = "Search Player";
                tbSP.ForeColor = c;
            }
            else
            {
                tbSP.ForeColor = Color.Black;
            }
        }
    }
}
