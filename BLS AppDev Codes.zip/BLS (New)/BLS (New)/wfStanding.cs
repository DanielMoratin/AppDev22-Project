﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BLS__New_
{
    public partial class wfStanding : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;
        public wfStanding()
        {
            InitializeComponent();
        }

        private void wfStanding_Load(object sender, EventArgs e)
        {
            refresh_Click(sender, e);
        }

        public void refresh_Click(object sender, EventArgs e)
        {
            String strDT = DateTime.Now.ToString("  MM/dd/yyyy  hh:mm:ss  tt");
            lbltime.Text = "Team Standings As Of  " + strDT;

            lvStanding.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Team Where [Status] = 'Active' Order by Loses");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                String itemWR;
                if (Convert.ToInt32(dr.GetValue(4).ToString()) == 0)
                    itemWR = 0 + "";
                else
                    itemWR =  (int)( ( Convert.ToDouble( dr.GetValue(4).ToString() ) / ( Convert.ToDouble( dr.GetValue(4).ToString() ) + Convert.ToDouble( dr.GetValue(5).ToString() ) ) ) * 100 ) + "";
                String itemName = dr.GetValue(1).ToString();
                String itemW = dr.GetValue(4).ToString();
                String itemL = dr.GetValue(5).ToString();
                String[] iRow = { itemWR, itemName, itemW, itemL };
                ListViewItem itemRow = new ListViewItem(iRow);
                lvStanding.Items.Add(itemRow);
            }
            con.Close();
        }
    }
}
