﻿namespace BLS__New_
{
    partial class wfTeam
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wfTeam));
            this.pAT = new System.Windows.Forms.Panel();
            this.btnSearchAT = new System.Windows.Forms.Button();
            this.tbSearchAT = new System.Windows.Forms.TextBox();
            this.cbATsort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lvAT = new System.Windows.Forms.ListView();
            this.lvTeamId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvTeamOwner = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvHometown = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refresh1 = new System.Windows.Forms.Label();
            this.pHeader = new System.Windows.Forms.Panel();
            this.lblDetial = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnAT = new System.Windows.Forms.Button();
            this.btnTR = new System.Windows.Forms.Button();
            this.pTR = new System.Windows.Forms.Panel();
            this.btnFP = new System.Windows.Forms.Button();
            this.tbSP = new System.Windows.Forms.TextBox();
            this.cbTeamName = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lvTR = new System.Windows.Forms.ListView();
            this.chPlayerLname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPlayerFname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chSP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refresh2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pp6 = new System.Windows.Forms.Panel();
            this.pp5 = new System.Windows.Forms.Panel();
            this.pp2 = new System.Windows.Forms.Panel();
            this.pp1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pAT.SuspendLayout();
            this.pHeader.SuspendLayout();
            this.pTR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pAT
            // 
            this.pAT.AutoScroll = true;
            this.pAT.Controls.Add(this.btnSearchAT);
            this.pAT.Controls.Add(this.tbSearchAT);
            this.pAT.Controls.Add(this.cbATsort);
            this.pAT.Controls.Add(this.label1);
            this.pAT.Controls.Add(this.lvAT);
            this.pAT.Controls.Add(this.refresh1);
            this.pAT.Location = new System.Drawing.Point(3, 105);
            this.pAT.Name = "pAT";
            this.pAT.Size = new System.Drawing.Size(680, 344);
            this.pAT.TabIndex = 7;
            // 
            // btnSearchAT
            // 
            this.btnSearchAT.Location = new System.Drawing.Point(314, 5);
            this.btnSearchAT.Name = "btnSearchAT";
            this.btnSearchAT.Size = new System.Drawing.Size(75, 24);
            this.btnSearchAT.TabIndex = 5;
            this.btnSearchAT.Text = "Find team";
            this.btnSearchAT.UseVisualStyleBackColor = true;
            this.btnSearchAT.Click += new System.EventHandler(this.btnSearchAT_Click);
            // 
            // tbSearchAT
            // 
            this.tbSearchAT.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSearchAT.Location = new System.Drawing.Point(390, 7);
            this.tbSearchAT.Name = "tbSearchAT";
            this.tbSearchAT.Size = new System.Drawing.Size(100, 20);
            this.tbSearchAT.TabIndex = 4;
            this.tbSearchAT.Text = "Search Team";
            this.tbSearchAT.TextChanged += new System.EventHandler(this.tbSearchAT_TextChanged);
            this.tbSearchAT.Enter += new System.EventHandler(this.tbSearchAT_Enter);
            this.tbSearchAT.Leave += new System.EventHandler(this.tbSearchAT_Leave);
            // 
            // cbATsort
            // 
            this.cbATsort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbATsort.FormattingEnabled = true;
            this.cbATsort.Items.AddRange(new object[] {
            "Name",
            "Owner"});
            this.cbATsort.Location = new System.Drawing.Point(68, 6);
            this.cbATsort.Name = "cbATsort";
            this.cbATsort.Size = new System.Drawing.Size(121, 21);
            this.cbATsort.TabIndex = 3;
            this.cbATsort.SelectedIndexChanged += new System.EventHandler(this.cbATsort_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sort by : ";
            // 
            // lvAT
            // 
            this.lvAT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvAT.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvTeamId,
            this.lvName,
            this.lvTeamOwner,
            this.lvHometown});
            this.lvAT.FullRowSelect = true;
            this.lvAT.GridLines = true;
            this.lvAT.HideSelection = false;
            this.lvAT.Location = new System.Drawing.Point(14, 31);
            this.lvAT.MultiSelect = false;
            this.lvAT.Name = "lvAT";
            this.lvAT.Size = new System.Drawing.Size(653, 298);
            this.lvAT.TabIndex = 1;
            this.lvAT.UseCompatibleStateImageBehavior = false;
            this.lvAT.View = System.Windows.Forms.View.Details;
            // 
            // lvTeamId
            // 
            this.lvTeamId.Text = "Team ID";
            this.lvTeamId.Width = 115;
            // 
            // lvName
            // 
            this.lvName.Text = "Team Name";
            this.lvName.Width = 187;
            // 
            // lvTeamOwner
            // 
            this.lvTeamOwner.Text = "Team Owner";
            this.lvTeamOwner.Width = 202;
            // 
            // lvHometown
            // 
            this.lvHometown.Text = "Hometown";
            this.lvHometown.Width = 138;
            // 
            // refresh1
            // 
            this.refresh1.AutoSize = true;
            this.refresh1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh1.ForeColor = System.Drawing.Color.Blue;
            this.refresh1.Location = new System.Drawing.Point(623, 9);
            this.refresh1.Name = "refresh1";
            this.refresh1.Size = new System.Drawing.Size(44, 13);
            this.refresh1.TabIndex = 0;
            this.refresh1.Text = "Refresh";
            this.refresh1.Click += new System.EventHandler(this.refresh1_Click);
            // 
            // pHeader
            // 
            this.pHeader.Controls.Add(this.pictureBox2);
            this.pHeader.Controls.Add(this.pp2);
            this.pHeader.Controls.Add(this.pp1);
            this.pHeader.Controls.Add(this.pp6);
            this.pHeader.Controls.Add(this.pp5);
            this.pHeader.Controls.Add(this.panel2);
            this.pHeader.Controls.Add(this.panel1);
            this.pHeader.Controls.Add(this.lblDetial);
            this.pHeader.Controls.Add(this.lblTitle);
            this.pHeader.Controls.Add(this.btnAT);
            this.pHeader.Controls.Add(this.btnTR);
            this.pHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pHeader.Location = new System.Drawing.Point(0, 0);
            this.pHeader.Name = "pHeader";
            this.pHeader.Size = new System.Drawing.Size(686, 100);
            this.pHeader.TabIndex = 6;
            // 
            // lblDetial
            // 
            this.lblDetial.AutoSize = true;
            this.lblDetial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetial.Location = new System.Drawing.Point(48, 42);
            this.lblDetial.Name = "lblDetial";
            this.lblDetial.Size = new System.Drawing.Size(269, 15);
            this.lblDetial.TabIndex = 4;
            this.lblDetial.Text = "Active Teams List As Of MM/dd/yyyy  hh:mm:ss  tt";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(34, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(384, 34);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "BASKETBALL LEAGUE SYSTEM TEAMS";
            // 
            // btnAT
            // 
            this.btnAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnAT.FlatAppearance.BorderSize = 0;
            this.btnAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAT.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAT.ForeColor = System.Drawing.Color.White;
            this.btnAT.Location = new System.Drawing.Point(45, 66);
            this.btnAT.Name = "btnAT";
            this.btnAT.Size = new System.Drawing.Size(106, 30);
            this.btnAT.TabIndex = 0;
            this.btnAT.Text = "All Teams";
            this.btnAT.UseVisualStyleBackColor = false;
            this.btnAT.Click += new System.EventHandler(this.btnAT_Click);
            // 
            // btnTR
            // 
            this.btnTR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnTR.FlatAppearance.BorderSize = 0;
            this.btnTR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTR.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTR.ForeColor = System.Drawing.Color.White;
            this.btnTR.Location = new System.Drawing.Point(211, 66);
            this.btnTR.Name = "btnTR";
            this.btnTR.Size = new System.Drawing.Size(106, 30);
            this.btnTR.TabIndex = 1;
            this.btnTR.Text = "Team Rosters";
            this.btnTR.UseVisualStyleBackColor = false;
            this.btnTR.Click += new System.EventHandler(this.btnTR_Click);
            // 
            // pTR
            // 
            this.pTR.AutoScroll = true;
            this.pTR.Controls.Add(this.btnFP);
            this.pTR.Controls.Add(this.tbSP);
            this.pTR.Controls.Add(this.cbTeamName);
            this.pTR.Controls.Add(this.label2);
            this.pTR.Controls.Add(this.lvTR);
            this.pTR.Controls.Add(this.refresh2);
            this.pTR.Location = new System.Drawing.Point(3, 105);
            this.pTR.Name = "pTR";
            this.pTR.Size = new System.Drawing.Size(680, 344);
            this.pTR.TabIndex = 8;
            // 
            // btnFP
            // 
            this.btnFP.Location = new System.Drawing.Point(395, 3);
            this.btnFP.Name = "btnFP";
            this.btnFP.Size = new System.Drawing.Size(75, 24);
            this.btnFP.TabIndex = 5;
            this.btnFP.Text = "Find player ";
            this.btnFP.UseVisualStyleBackColor = true;
            // 
            // tbSP
            // 
            this.tbSP.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSP.Location = new System.Drawing.Point(471, 5);
            this.tbSP.Name = "tbSP";
            this.tbSP.Size = new System.Drawing.Size(100, 20);
            this.tbSP.TabIndex = 4;
            this.tbSP.Text = "Search Player";
            this.tbSP.TextChanged += new System.EventHandler(this.tbSP_TextChanged);
            this.tbSP.Enter += new System.EventHandler(this.tbSP_Enter);
            this.tbSP.Leave += new System.EventHandler(this.tbSP_Leave);
            // 
            // cbTeamName
            // 
            this.cbTeamName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTeamName.FormattingEnabled = true;
            this.cbTeamName.Location = new System.Drawing.Point(95, 6);
            this.cbTeamName.Name = "cbTeamName";
            this.cbTeamName.Size = new System.Drawing.Size(198, 21);
            this.cbTeamName.TabIndex = 3;
            this.cbTeamName.SelectedIndexChanged += new System.EventHandler(this.cbTeamName_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select Team : ";
            // 
            // lvTR
            // 
            this.lvTR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvTR.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chPlayerLname,
            this.chPlayerFname,
            this.chPP,
            this.chSP});
            this.lvTR.FullRowSelect = true;
            this.lvTR.GridLines = true;
            this.lvTR.HideSelection = false;
            this.lvTR.Location = new System.Drawing.Point(14, 31);
            this.lvTR.MultiSelect = false;
            this.lvTR.Name = "lvTR";
            this.lvTR.Size = new System.Drawing.Size(653, 298);
            this.lvTR.TabIndex = 1;
            this.lvTR.UseCompatibleStateImageBehavior = false;
            this.lvTR.View = System.Windows.Forms.View.Details;
            // 
            // chPlayerLname
            // 
            this.chPlayerLname.Text = "Last Name";
            this.chPlayerLname.Width = 145;
            // 
            // chPlayerFname
            // 
            this.chPlayerFname.Text = "First Name";
            this.chPlayerFname.Width = 145;
            // 
            // chPP
            // 
            this.chPP.Text = "Primary Position";
            this.chPP.Width = 180;
            // 
            // chSP
            // 
            this.chSP.Text = "Secondary Position";
            this.chSP.Width = 180;
            // 
            // refresh2
            // 
            this.refresh2.AutoSize = true;
            this.refresh2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh2.ForeColor = System.Drawing.Color.Blue;
            this.refresh2.Location = new System.Drawing.Point(623, 9);
            this.refresh2.Name = "refresh2";
            this.refresh2.Size = new System.Drawing.Size(44, 13);
            this.refresh2.TabIndex = 0;
            this.refresh2.Text = "Refresh";
            this.refresh2.Click += new System.EventHandler(this.refresh2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(0, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(686, 3);
            this.panel2.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(686, 1);
            this.panel1.TabIndex = 16;
            // 
            // pp6
            // 
            this.pp6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp6.Location = new System.Drawing.Point(307, 66);
            this.pp6.Name = "pp6";
            this.pp6.Size = new System.Drawing.Size(10, 28);
            this.pp6.TabIndex = 23;
            this.pp6.Visible = false;
            // 
            // pp5
            // 
            this.pp5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp5.Location = new System.Drawing.Point(211, 66);
            this.pp5.Name = "pp5";
            this.pp5.Size = new System.Drawing.Size(10, 28);
            this.pp5.TabIndex = 22;
            this.pp5.Visible = false;
            // 
            // pp2
            // 
            this.pp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp2.Location = new System.Drawing.Point(141, 66);
            this.pp2.Name = "pp2";
            this.pp2.Size = new System.Drawing.Size(10, 28);
            this.pp2.TabIndex = 25;
            this.pp2.Visible = false;
            // 
            // pp1
            // 
            this.pp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pp1.Location = new System.Drawing.Point(45, 66);
            this.pp1.Name = "pp1";
            this.pp1.Size = new System.Drawing.Size(10, 28);
            this.pp1.TabIndex = 24;
            this.pp1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(582, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(101, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 26;
            this.pictureBox2.TabStop = false;
            // 
            // wfTeam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pTR);
            this.Controls.Add(this.pAT);
            this.Controls.Add(this.pHeader);
            this.Name = "wfTeam";
            this.Size = new System.Drawing.Size(686, 450);
            this.Load += new System.EventHandler(this.wfTeam_Load);
            this.pAT.ResumeLayout(false);
            this.pAT.PerformLayout();
            this.pHeader.ResumeLayout(false);
            this.pHeader.PerformLayout();
            this.pTR.ResumeLayout(false);
            this.pTR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pAT;
        private System.Windows.Forms.Button btnSearchAT;
        private System.Windows.Forms.TextBox tbSearchAT;
        private System.Windows.Forms.ComboBox cbATsort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lvAT;
        private System.Windows.Forms.ColumnHeader lvTeamId;
        private System.Windows.Forms.ColumnHeader lvName;
        private System.Windows.Forms.ColumnHeader lvTeamOwner;
        private System.Windows.Forms.ColumnHeader lvHometown;
        private System.Windows.Forms.Label refresh1;
        private System.Windows.Forms.Panel pHeader;
        private System.Windows.Forms.Label lblDetial;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnAT;
        private System.Windows.Forms.Button btnTR;
        private System.Windows.Forms.Panel pTR;
        private System.Windows.Forms.Button btnFP;
        private System.Windows.Forms.TextBox tbSP;
        private System.Windows.Forms.ComboBox cbTeamName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lvTR;
        private System.Windows.Forms.ColumnHeader chPlayerLname;
        private System.Windows.Forms.ColumnHeader chPlayerFname;
        private System.Windows.Forms.ColumnHeader chPP;
        private System.Windows.Forms.ColumnHeader chSP;
        private System.Windows.Forms.Label refresh2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pp6;
        private System.Windows.Forms.Panel pp5;
        private System.Windows.Forms.Panel pp2;
        private System.Windows.Forms.Panel pp1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
