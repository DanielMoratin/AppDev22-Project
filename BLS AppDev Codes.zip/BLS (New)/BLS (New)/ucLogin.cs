﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BLS__New_
{
    public partial class ucLogin : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;
        FormBLS fbls;
        Color c;
        public ucLogin()
        {
            InitializeComponent();
        }

        public void getForm(FormBLS f)
        {
            fbls = f;
        }

        private void ucLogin_Load(object sender, EventArgs e)
        {
            c = loginPassword.ForeColor;
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            Boolean b = true;
            con.Open();
            cmd = new SqlCommand("Select * from Admin");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.GetValue(1).ToString() == loginID.Text && dr.GetValue(2).ToString() == loginPassword.Text)
                {
                    fbls.btnF.Visible = true;
                    fbls.btnG.Visible = true;
                    fbls.btnChange.Visible = true;
                    fbls.btnLog.Text = "Logout";
                    fbls.btnMM_Click(sender, e);
                    fbls.closeLogin();
                    fbls.loginAdmin(dr.GetValue(1).ToString());
                    b = false;
                    errorP.Visible = false;
                    loginID.Text = "";
                    loginID_Leave(sender, e);
                    loginPassword.Text = "";
                    loginPassword_Leave(sender, e);
                }
            }
            if (b)
            {
                errorP.Visible = true;
            }

            con.Close();
        }

        private void btnGuest_Click(object sender, EventArgs e)
        {
            fbls.btnF.Visible = false;
            fbls.btnG.Visible = false;
            fbls.btnChange.Visible = false;
            fbls.btnLog.Text = "Sign In";
            fbls.btnMM_Click(sender ,e);
            fbls.closeLogin();
            errorP.Visible = false;
        }

        private void loginPassword_Enter(object sender, EventArgs e)
        {
            if (loginPassword.Text == "Password")
            {
                loginPassword.Text = "";
                loginPassword.ForeColor = Color.Black;
                loginPassword.UseSystemPasswordChar = true;
            }
        }

        private void loginPassword_Leave(object sender, EventArgs e)
        {
            if (loginPassword.Text == "")
            {
                loginPassword.Text = "Password";
                loginPassword.ForeColor = c;
                loginPassword.UseSystemPasswordChar = false;
            }
            else
            {
                loginPassword.ForeColor = Color.Black;
            }
        }

        private void loginID_Enter(object sender, EventArgs e)
        {
            if (loginID.Text == "Username")
            {
                loginID.Text = "";
                loginID.ForeColor = Color.Black;
            }
        }

        private void loginID_Leave(object sender, EventArgs e)
        {
            if (loginID.Text == "")
            {
                loginID.Text = "Username";
                loginID.ForeColor = c;
            }
            else loginID.ForeColor = Color.Black;
        }

        private void loginSP_CheckedChanged(object sender, EventArgs e)
        {
            if (loginSP.Checked)
            {
                loginPassword.UseSystemPasswordChar = false;
            }
            else
            {
                if (loginPassword.Text == "Password")
                {
                    loginPassword.UseSystemPasswordChar = false;
                }
                else
                loginPassword.UseSystemPasswordChar = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
