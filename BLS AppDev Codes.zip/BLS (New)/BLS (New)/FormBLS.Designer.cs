﻿namespace BLS__New_
{
    partial class FormBLS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBLS));
            this.btnMM = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnT = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pClick = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnStand = new System.Windows.Forms.Button();
            this.btnGs = new System.Windows.Forms.Button();
            this.ucLogin1 = new BLS__New_.ucLogin();
            this.wfMainMenu1 = new BLS__New_.wfMainMenu();
            this.wfGame1 = new BLS__New_.wfGame();
            this.wfPostGame1 = new BLS__New_.wfPostGame();
            this.wfStanding1 = new BLS__New_.wfStanding();
            this.wfTeam = new BLS__New_.wfTeam();
            this.wfPlayer1 = new BLS__New_.wfPlayer();
            this.wfFile1 = new BLS__New_.wfFile();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMM
            // 
            this.btnMM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMM.FlatAppearance.BorderSize = 0;
            this.btnMM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMM.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMM.ForeColor = System.Drawing.Color.White;
            this.btnMM.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMM.Location = new System.Drawing.Point(46, 16);
            this.btnMM.Name = "btnMM";
            this.btnMM.Size = new System.Drawing.Size(65, 57);
            this.btnMM.TabIndex = 0;
            this.btnMM.Text = "Basketball\r\nLeague\r\nSystem\r\n";
            this.btnMM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMM.UseVisualStyleBackColor = true;
            this.btnMM.Click += new System.EventHandler(this.btnMM_Click);
            // 
            // btnP
            // 
            this.btnP.FlatAppearance.BorderSize = 0;
            this.btnP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnP.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnP.ForeColor = System.Drawing.Color.White;
            this.btnP.Location = new System.Drawing.Point(3, 171);
            this.btnP.Name = "btnP";
            this.btnP.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnP.Size = new System.Drawing.Size(108, 35);
            this.btnP.TabIndex = 1;
            this.btnP.TabStop = false;
            this.btnP.Text = "Players";
            this.btnP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnP.UseVisualStyleBackColor = true;
            this.btnP.Click += new System.EventHandler(this.btnP_Click);
            // 
            // btnT
            // 
            this.btnT.FlatAppearance.BorderSize = 0;
            this.btnT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnT.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnT.ForeColor = System.Drawing.Color.White;
            this.btnT.Location = new System.Drawing.Point(3, 207);
            this.btnT.Name = "btnT";
            this.btnT.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnT.Size = new System.Drawing.Size(108, 35);
            this.btnT.TabIndex = 2;
            this.btnT.TabStop = false;
            this.btnT.Text = "Teams";
            this.btnT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnT.UseVisualStyleBackColor = true;
            this.btnT.Click += new System.EventHandler(this.btnT_Click);
            // 
            // btnF
            // 
            this.btnF.FlatAppearance.BorderSize = 0;
            this.btnF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF.ForeColor = System.Drawing.Color.White;
            this.btnF.Location = new System.Drawing.Point(3, 243);
            this.btnF.Name = "btnF";
            this.btnF.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnF.Size = new System.Drawing.Size(108, 35);
            this.btnF.TabIndex = 4;
            this.btnF.TabStop = false;
            this.btnF.Text = "File";
            this.btnF.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // btnG
            // 
            this.btnG.FlatAppearance.BorderSize = 0;
            this.btnG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnG.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG.ForeColor = System.Drawing.Color.White;
            this.btnG.Location = new System.Drawing.Point(3, 279);
            this.btnG.Name = "btnG";
            this.btnG.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnG.Size = new System.Drawing.Size(108, 35);
            this.btnG.TabIndex = 5;
            this.btnG.TabStop = false;
            this.btnG.Text = "Post Game";
            this.btnG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnG.UseVisualStyleBackColor = true;
            this.btnG.Click += new System.EventHandler(this.btnG_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.btnChange);
            this.panel1.Controls.Add(this.btnLog);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.pClick);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnStand);
            this.panel1.Controls.Add(this.btnGs);
            this.panel1.Controls.Add(this.btnMM);
            this.panel1.Controls.Add(this.btnG);
            this.panel1.Controls.Add(this.btnP);
            this.panel1.Controls.Add(this.btnF);
            this.panel1.Controls.Add(this.btnT);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(114, 450);
            this.panel1.TabIndex = 6;
            // 
            // btnChange
            // 
            this.btnChange.FlatAppearance.BorderSize = 0;
            this.btnChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChange.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChange.ForeColor = System.Drawing.Color.White;
            this.btnChange.Location = new System.Drawing.Point(45, 389);
            this.btnChange.Name = "btnChange";
            this.btnChange.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnChange.Size = new System.Drawing.Size(66, 25);
            this.btnChange.TabIndex = 12;
            this.btnChange.Text = "Account";
            this.btnChange.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnLog
            // 
            this.btnLog.FlatAppearance.BorderSize = 0;
            this.btnLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLog.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLog.ForeColor = System.Drawing.Color.White;
            this.btnLog.Location = new System.Drawing.Point(45, 420);
            this.btnLog.Name = "btnLog";
            this.btnLog.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnLog.Size = new System.Drawing.Size(63, 25);
            this.btnLog.TabIndex = 11;
            this.btnLog.Text = "Sign In";
            this.btnLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClose.Location = new System.Drawing.Point(4, 413);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(35, 34);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "x";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pClick
            // 
            this.pClick.BackColor = System.Drawing.Color.White;
            this.pClick.Location = new System.Drawing.Point(0, 99);
            this.pClick.Name = "pClick";
            this.pClick.Size = new System.Drawing.Size(5, 35);
            this.pClick.TabIndex = 9;
            this.pClick.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnStand
            // 
            this.btnStand.FlatAppearance.BorderSize = 0;
            this.btnStand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStand.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStand.ForeColor = System.Drawing.Color.White;
            this.btnStand.Location = new System.Drawing.Point(3, 135);
            this.btnStand.Name = "btnStand";
            this.btnStand.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnStand.Size = new System.Drawing.Size(108, 35);
            this.btnStand.TabIndex = 7;
            this.btnStand.TabStop = false;
            this.btnStand.Text = "Standings";
            this.btnStand.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStand.UseVisualStyleBackColor = true;
            this.btnStand.Click += new System.EventHandler(this.btnStand_Click);
            // 
            // btnGs
            // 
            this.btnGs.FlatAppearance.BorderSize = 0;
            this.btnGs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGs.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGs.ForeColor = System.Drawing.Color.White;
            this.btnGs.Location = new System.Drawing.Point(3, 99);
            this.btnGs.Name = "btnGs";
            this.btnGs.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnGs.Size = new System.Drawing.Size(108, 35);
            this.btnGs.TabIndex = 6;
            this.btnGs.TabStop = false;
            this.btnGs.Text = "Games";
            this.btnGs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGs.UseVisualStyleBackColor = true;
            this.btnGs.Click += new System.EventHandler(this.btnGs_Click);
            // 
            // ucLogin1
            // 
            this.ucLogin1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ucLogin1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ucLogin1.BackgroundImage")));
            this.ucLogin1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ucLogin1.Location = new System.Drawing.Point(0, 0);
            this.ucLogin1.Name = "ucLogin1";
            this.ucLogin1.Size = new System.Drawing.Size(800, 450);
            this.ucLogin1.TabIndex = 13;
            // 
            // wfMainMenu1
            // 
            this.wfMainMenu1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.wfMainMenu1.Location = new System.Drawing.Point(114, 0);
            this.wfMainMenu1.Name = "wfMainMenu1";
            this.wfMainMenu1.Size = new System.Drawing.Size(686, 450);
            this.wfMainMenu1.TabIndex = 10;
            // 
            // wfGame1
            // 
            this.wfGame1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.wfGame1.Location = new System.Drawing.Point(114, 0);
            this.wfGame1.Name = "wfGame1";
            this.wfGame1.Size = new System.Drawing.Size(686, 450);
            this.wfGame1.TabIndex = 12;
            // 
            // wfPostGame1
            // 
            this.wfPostGame1.Location = new System.Drawing.Point(114, 0);
            this.wfPostGame1.Name = "wfPostGame1";
            this.wfPostGame1.Size = new System.Drawing.Size(686, 450);
            this.wfPostGame1.TabIndex = 11;
            // 
            // wfStanding1
            // 
            this.wfStanding1.Location = new System.Drawing.Point(114, 0);
            this.wfStanding1.Name = "wfStanding1";
            this.wfStanding1.Size = new System.Drawing.Size(686, 450);
            this.wfStanding1.TabIndex = 10;
            // 
            // wfTeam
            // 
            this.wfTeam.Location = new System.Drawing.Point(114, 0);
            this.wfTeam.Name = "wfTeam";
            this.wfTeam.Size = new System.Drawing.Size(686, 450);
            this.wfTeam.TabIndex = 6;
            // 
            // wfPlayer1
            // 
            this.wfPlayer1.AutoScroll = true;
            this.wfPlayer1.Location = new System.Drawing.Point(114, 0);
            this.wfPlayer1.Name = "wfPlayer1";
            this.wfPlayer1.Size = new System.Drawing.Size(686, 450);
            this.wfPlayer1.TabIndex = 8;
            // 
            // wfFile1
            // 
            this.wfFile1.AutoScroll = true;
            this.wfFile1.Location = new System.Drawing.Point(114, 0);
            this.wfFile1.Name = "wfFile1";
            this.wfFile1.Size = new System.Drawing.Size(686, 450);
            this.wfFile1.TabIndex = 7;
            // 
            // FormBLS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ucLogin1);
            this.Controls.Add(this.wfMainMenu1);
            this.Controls.Add(this.wfGame1);
            this.Controls.Add(this.wfPostGame1);
            this.Controls.Add(this.wfStanding1);
            this.Controls.Add(this.wfTeam);
            this.Controls.Add(this.wfPlayer1);
            this.Controls.Add(this.wfFile1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "FormBLS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BLS";
            this.Load += new System.EventHandler(this.FormBLS_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMM;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Button btnT;
        private System.Windows.Forms.Panel panel1;
        private wfFile wfFile1;
        private wfPlayer wfPlayer1;
        private wfTeam wfTeam;
        private System.Windows.Forms.Button btnGs;
        private wfStanding wfStanding1;
        private wfPostGame wfPostGame1;
        private System.Windows.Forms.Button btnStand;
        private wfGame wfGame1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pClick;
        private wfMainMenu wfMainMenu1;
        private System.Windows.Forms.Button btnClose;
        private ucLogin ucLogin1;
        public System.Windows.Forms.Button btnF;
        public System.Windows.Forms.Button btnG;
        public System.Windows.Forms.Button btnLog;
        public System.Windows.Forms.Button btnChange;
    }
}

