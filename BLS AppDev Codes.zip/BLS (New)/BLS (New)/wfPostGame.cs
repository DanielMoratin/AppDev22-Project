﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BLS__New_
{
    public partial class wfPostGame : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\ProjectsV13;Initial Catalog=dbBLS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand cmd;
        SqlDataReader dr;

        FormBLS fb;
        String st1, st2;
        public wfPostGame()
        {
            InitializeComponent();
        }

        private void wfPostGame_Load(object sender, EventArgs e)
        {
            st1 = cmTeam1.SelectedItem + "";
            st2 = cbTeam2.SelectedItem + "";
            displayTeams();
        }

        public void getFB(FormBLS fb)
        {
            this.fb = fb;
        }
        public void refresh_Click(object sender, EventArgs e)
        {
            displayTeams();
            tbScore1.Text = "";
            tbScore2.Text = "";
        }

        public void displayTeams()
        {
            int cnt = 0;
            cmTeam1.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Team Where [Status] = 'Active'");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cmTeam1.Items.Add(dr.GetValue(1).ToString());
                cnt++;
            }
            con.Close();
            if (cnt != 0) cmTeam1.SelectedIndex = 0;

            String str1 = cmTeam1.SelectedItem + "", str2 = cbTeam2.SelectedItem + "";

            int cnt1 = 0;
            cbTeam2.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Team Where [Status] = 'Active'");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (str1 != dr.GetValue(1).ToString()) {
                    cbTeam2.Items.Add(dr.GetValue(1).ToString());
                    cnt1++;
                }
            }
            con.Close();
            if (cnt1 != 0) cbTeam2.SelectedIndex = 0;

            str1 = cmTeam1.SelectedItem + ""; str2 = cbTeam2.SelectedItem + "";

            int cnt2 = 0;
            cmTeam1.Items.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from Team Where [Status] = 'Active'");
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.GetValue(1).ToString() != str2)
                {
                    cmTeam1.Items.Add(dr.GetValue(1).ToString());
                    cnt2++;
                }
            }
            con.Close();
            if (cnt2 != 0) cmTeam1.SelectedIndex = 0;

            cbTeam2.Items.Remove(st1);
        }

        private void cmTeam1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String str = cmTeam1.SelectedItem + "";
            cbTeam2.Items.Remove(str);
            cbTeam2.Items.Add(st1);
            st1 = str;
        }

        private void cbTeam2_SelectedIndexChanged(object sender, EventArgs e)
        {
            String str = cbTeam2.SelectedItem + "";
            cmTeam1.Items.Remove(str);
            cmTeam1.Items.Add(st2);
            st2 = str;
        }

        private void btnPostGame_Click(object sender, EventArgs e)
        {
            if (tbScore1.Text != "")
            {
                con.Open();
                if (Convert.ToInt32(tbScore1.Text) > Convert.ToInt32(tbScore2.Text)) cmd = new SqlCommand("Update Team Set [Wins] += 1 Where [Name] = @name");
                else cmd = new SqlCommand("Update Team Set [Loses] += 1 Where [Name] = @name");
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@name", cmTeam1.SelectedItem);
                cmd.ExecuteNonQuery();
                con.Close();
                eTS1.Visible = false;
            }
            else eTS1.Visible = true;
            if (tbScore2.Text != "") {
                con.Open();
                if (Convert.ToInt32(tbScore2.Text) > Convert.ToInt32(tbScore1.Text)) cmd = new SqlCommand("Update Team Set [Wins] += 1 Where [Name] = @name");
                else cmd = new SqlCommand("Update Team Set [Loses] += 1 Where [Name] = @name");
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@name", cbTeam2.SelectedItem);
                cmd.ExecuteNonQuery();
                con.Close();
                eTS2.Visible = false;
            }
            else eTS2.Visible = true;

            if (eTS2.Visible == false && eTS1.Visible == false) {
                con.Open();
                cmd = new SqlCommand("Select count(*) + 1 from Game");
                cmd.Connection = con;
                int gNo = Convert.ToInt32(cmd.ExecuteScalar().ToString());
                con.Close();
                con.Open();
                cmd = new SqlCommand("AddGame");
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@no", gNo);
                cmd.Parameters.AddWithValue("@t1n", cmTeam1.SelectedItem);
                cmd.Parameters.AddWithValue("@t1s", tbScore1.Text);
                cmd.Parameters.AddWithValue("@t2n", cbTeam2.SelectedItem);
                cmd.Parameters.AddWithValue("@t2s", tbScore2.Text);
                DateTime now = DateTime.Now;
                cmd.Parameters.AddWithValue("@sched", now.Day + "/" + now.Month + "/" + now.Year + "  " + now.Hour + ":" + now.Minute + ":" + now.Second + " " + now.TimeOfDay);
                cmd.ExecuteNonQuery();
                con.Close();

                refresh_Click(sender, e);
                fb.refreshAll(sender, e);
            }
        }

        private void tbScore2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if (!Char.IsDigit(c) && c != 8)
            {
                e.Handled = true;
                eTS2.Visible = true;
            }
            else
            {
                eTS2.Visible = false;
            }
        }

        private void tbScore1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if (!Char.IsDigit(c) && c != 8)
            {
                e.Handled = true;
                eTS1.Visible = true;
            }
            else
            {
                eTS1.Visible = false;
            }
        }
    }
}
