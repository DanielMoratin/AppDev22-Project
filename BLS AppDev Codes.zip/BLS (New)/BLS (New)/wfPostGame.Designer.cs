﻿namespace BLS__New_
{
    partial class wfPostGame
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wfPostGame));
            this.cmTeam1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbTeam2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPostGame = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbScore1 = new System.Windows.Forms.TextBox();
            this.tbScore2 = new System.Windows.Forms.TextBox();
            this.eTS1 = new System.Windows.Forms.Label();
            this.eTS2 = new System.Windows.Forms.Label();
            this.refresh = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // cmTeam1
            // 
            this.cmTeam1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmTeam1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmTeam1.FormattingEnabled = true;
            this.cmTeam1.Location = new System.Drawing.Point(170, 193);
            this.cmTeam1.Name = "cmTeam1";
            this.cmTeam1.Size = new System.Drawing.Size(163, 25);
            this.cmTeam1.TabIndex = 1;
            this.cmTeam1.SelectedIndexChanged += new System.EventHandler(this.cmTeam1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select Team 1 : ";
            // 
            // cbTeam2
            // 
            this.cbTeam2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTeam2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTeam2.FormattingEnabled = true;
            this.cbTeam2.Location = new System.Drawing.Point(170, 250);
            this.cbTeam2.Name = "cbTeam2";
            this.cbTeam2.Size = new System.Drawing.Size(163, 25);
            this.cbTeam2.TabIndex = 3;
            this.cbTeam2.SelectedIndexChanged += new System.EventHandler(this.cbTeam2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(79, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Select Team 2 : ";
            // 
            // btnPostGame
            // 
            this.btnPostGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.btnPostGame.FlatAppearance.BorderSize = 0;
            this.btnPostGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPostGame.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPostGame.ForeColor = System.Drawing.Color.White;
            this.btnPostGame.Location = new System.Drawing.Point(296, 349);
            this.btnPostGame.Name = "btnPostGame";
            this.btnPostGame.Size = new System.Drawing.Size(87, 36);
            this.btnPostGame.TabIndex = 5;
            this.btnPostGame.Text = "Post Game";
            this.btnPostGame.UseVisualStyleBackColor = false;
            this.btnPostGame.Click += new System.EventHandler(this.btnPostGame_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(369, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Team 1 Final Score : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(369, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Team 2 Final Score : ";
            // 
            // tbScore1
            // 
            this.tbScore1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbScore1.Location = new System.Drawing.Point(483, 193);
            this.tbScore1.MaxLength = 3;
            this.tbScore1.Name = "tbScore1";
            this.tbScore1.Size = new System.Drawing.Size(61, 22);
            this.tbScore1.TabIndex = 2;
            this.tbScore1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbScore1_KeyPress);
            // 
            // tbScore2
            // 
            this.tbScore2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbScore2.Location = new System.Drawing.Point(483, 251);
            this.tbScore2.MaxLength = 3;
            this.tbScore2.Name = "tbScore2";
            this.tbScore2.Size = new System.Drawing.Size(61, 22);
            this.tbScore2.TabIndex = 4;
            this.tbScore2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbScore2_KeyPress);
            // 
            // eTS1
            // 
            this.eTS1.AutoSize = true;
            this.eTS1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eTS1.ForeColor = System.Drawing.Color.Red;
            this.eTS1.Location = new System.Drawing.Point(369, 216);
            this.eTS1.Name = "eTS1";
            this.eTS1.Size = new System.Drawing.Size(190, 17);
            this.eTS1.TabIndex = 8;
            this.eTS1.Text = "*Please enter the value of final score*";
            this.eTS1.Visible = false;
            // 
            // eTS2
            // 
            this.eTS2.AutoSize = true;
            this.eTS2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eTS2.ForeColor = System.Drawing.Color.Red;
            this.eTS2.Location = new System.Drawing.Point(369, 274);
            this.eTS2.Name = "eTS2";
            this.eTS2.Size = new System.Drawing.Size(190, 17);
            this.eTS2.TabIndex = 9;
            this.eTS2.Text = "*Please enter the value of final score*";
            this.eTS2.Visible = false;
            // 
            // refresh
            // 
            this.refresh.AutoSize = true;
            this.refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.refresh.Location = new System.Drawing.Point(611, 133);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(44, 13);
            this.refresh.TabIndex = 10;
            this.refresh.Text = "Refresh";
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(31, 31);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(131, 34);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "POST GAME";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(0, 92);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(686, 3);
            this.panel2.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 91);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(686, 1);
            this.panel1.TabIndex = 12;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(168, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 72);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // wfPostGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.refresh);
            this.Controls.Add(this.eTS2);
            this.Controls.Add(this.eTS1);
            this.Controls.Add(this.tbScore2);
            this.Controls.Add(this.tbScore1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnPostGame);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbTeam2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmTeam1);
            this.Name = "wfPostGame";
            this.Size = new System.Drawing.Size(686, 450);
            this.Load += new System.EventHandler(this.wfPostGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmTeam1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbTeam2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPostGame;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbScore1;
        private System.Windows.Forms.TextBox tbScore2;
        private System.Windows.Forms.Label eTS1;
        private System.Windows.Forms.Label eTS2;
        private System.Windows.Forms.Label refresh;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
